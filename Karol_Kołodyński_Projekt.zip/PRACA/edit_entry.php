<?php
session_start();

// Konfiguracja bezpieczeństwa i błędów
ini_set('disable_functions', 'exec,shell_exec,system,passthru');
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
header("X-XSS-Protection: 1; mode=block");
header("X-Content-Type-Options: nosniff");

// Sprawdzenie autoryzacji
if (!isset($_SESSION['user'])) {
    header("Location: login_page.php");
    exit();
}

// Inicjalizacja połączenia z bazą
$connection = mysqli_connect("localhost", "root", "", "afryka_blog");
if (!$connection) {
    die("Błąd połączenia: " . mysqli_connect_error());
}

// Generowanie tokena CSRF
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Walidacja ID wpisu
$entry_id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$entry_id) {
    $_SESSION['error'] = "Nieprawidłowy identyfikator wpisu";
    header("Location: history_in_entry_page_user.php");
    exit();
}

// Pobranie istniejącego wpisu
$username = htmlspecialchars($_SESSION['user'], ENT_QUOTES, 'UTF-8');
$query = "SELECT * FROM wpisy WHERE id = ? AND author = ?";
$stmt = mysqli_prepare($connection, $query);
mysqli_stmt_bind_param($stmt, "is", $entry_id, $username);
mysqli_stmt_execute($stmt);

// POPRAWKA: Zamknięcie pierwszego zapytania przed nowymi operacjami
$result = mysqli_stmt_get_result($stmt);
$entry = mysqli_fetch_assoc($result);
mysqli_free_result($result); // Dodane zwolnienie wyników
mysqli_stmt_close($stmt); // Dodane zamknięcie statement

// Pobranie danych personalizacji
$query = "SELECT custom_greeting, custom_css_path FROM rejestracjatesy WHERE username = ?";
$stmt = mysqli_prepare($connection, $query);
mysqli_stmt_bind_param($stmt, "s", $username);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$row = mysqli_fetch_assoc($result);

$custom_greeting = htmlspecialchars($row['custom_greeting'] ?? 'Witaj', ENT_QUOTES, 'UTF-8');
$custom_css = htmlspecialchars($row['custom_css_path'] ?? '', ENT_QUOTES, 'UTF-8');
mysqli_free_result($result); // Dodane
mysqli_stmt_close($stmt); // Dodane

if (!$entry) {
    $_SESSION['error'] = "Brak uprawnień lub wpis nie istnieje!";
    header("Location: history_in_entry_page_user.php");
    exit();
}

// Obsługa formularza edycji
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Weryfikacja CSRF
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die("Nieprawidłowy token CSRF");
    }

    // Walidacja danych
    $nazwa = filter_input(INPUT_POST, 'nazwa', FILTER_SANITIZE_STRING);
    $opis = filter_input(INPUT_POST, 'opis', FILTER_SANITIZE_STRING);
    $gatunek = filter_input(INPUT_POST, 'gatunek', FILTER_SANITIZE_STRING);
    $waga = filter_input(INPUT_POST, 'waga', FILTER_VALIDATE_FLOAT, [
        'options' => [
            'min_range' => 0.01,
            'max_range' => 10000
        ]
    ]);

    if ($waga === false) {
        $_SESSION['error'] = "Nieprawidłowa wartość wagi (0.01 - 10000 kg)";
        header("Location: edit_entry.php?id=$entry_id");
        exit();
    }

    // Obsługa obrazka
    $image_data = $entry['obrazek'];
    if (!empty($_FILES['obrazek']['tmp_name'])) {
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $file_type = finfo_file($finfo, $_FILES['obrazek']['tmp_name']);
        finfo_close($finfo);

        $allowed_types = ['image/jpeg' => 'jpeg', 'image/png' => 'png'];
        if (!array_key_exists($file_type, $allowed_types)) {
            $_SESSION['error'] = "Dozwolone tylko pliki JPEG/PNG!";
            header("Location: edit_entry.php?id=$entry_id");
            exit();
        }

        if ($_FILES['obrazek']['size'] > 2 * 1024 * 1024) {
            $_SESSION['error'] = "Plik jest zbyt duży (max 2MB)";
            header("Location: edit_entry.php?id=$entry_id");
            exit();
        }

        $image_data = file_get_contents($_FILES['obrazek']['tmp_name']);
        if ($image_data === false) {
            $_SESSION['error'] = "Błąd odczytu pliku";
            header("Location: edit_entry.php?id=$entry_id");
            exit();
        }
    }

    // Aktualizacja wpisu
    try {
        $query = "UPDATE wpisy SET 
            nazwa = ?, 
            opis = ?, 
            gatunek = ?, 
            waga = ?, 
            obrazek = ? 
            WHERE id = ? AND author = ?";
        
        $stmt = mysqli_prepare($connection, $query);
        
        // Bind parametrów
        $null = NULL;
        mysqli_stmt_bind_param(
            $stmt,
            "sssdbis",
            $nazwa,
            $opis,
            $gatunek,
            $waga,
            $null,
            $entry_id,
            $username
        );
        
        // Obsługa BLOB
        if ($image_data !== $entry['obrazek']) {
            mysqli_stmt_send_long_data($stmt, 4, $image_data);
        }
        
        if (mysqli_stmt_execute($stmt)) {
            $_SESSION['success'] = "Wpis zaktualizowany!";
            header("Location: history_in_entry_page_user.php");
        } else {
            throw new Exception("Błąd aktualizacji: " . mysqli_error($connection));
        }
    } catch (Exception $e) {
        error_log($e->getMessage());
        $_SESSION['error'] = "Wystąpił błąd podczas aktualizacji wpisu";
        header("Location: edit_entry.php?id=$entry_id");
    }
    exit();
}
?>

<!DOCTYPE html>
<html lang="pl-PL">
<head>
    <title>Edytuj wpis</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/responsive_user.css">
    <style>
        .current-image img {
            max-width: 300px;
            margin: 10px 0;
            border: 1px solid #ddd;
            padding: 5px;
        }
        .error {
            color: red;
            margin: 10px 0;
        }
    </style>
    <?php if (!empty($custom_css)): ?>
    <link rel="stylesheet" href="<?php echo $custom_css; ?>">
    <?php endif; ?>
</head>
<body>
    <nav class="navbar">
        <ul class="menu">
            <li><a href="history_in_entry_page_user.php">Powrót</a></li>
            <li><a href="mainpage_user.php">Strona główna</a></li>
        </ul>
    </nav>

    <div class="container">
        <h2>Edytuj wpis #<?= htmlspecialchars($entry_id) ?></h2>
        
        <?php if (isset($_SESSION['error'])): ?>
            <div class="error"><?= htmlspecialchars($_SESSION['error']) ?></div>
            <?php unset($_SESSION['error']) ?>
        <?php endif; ?>

        <form method="post" enctype="multipart/form-data">
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
            
            <div class="form-group">
                <label>Nazwa zwierzęcia:
                    <input type="text" name="nazwa" 
                           value="<?= htmlspecialchars($entry['nazwa']) ?>" 
                           required maxlength="100">
                </label>
            </div>
            
            <div class="form-group">
                <label>Opis:
                    <textarea name="opis" required maxlength="2000"><?= 
                        htmlspecialchars($entry['opis']) 
                    ?></textarea>
                </label>
            </div>
            
            <div class="form-group">
                <label>Gatunek:
                    <select name="gatunek" required>
                        <?php
                        $gatunki = ['Ssak', 'Ptak', 'Gad', 'Płaz', 'Ryba', 'Stawonoga', 'Inny'];
                        foreach ($gatunki as $g) {
                            $safe_g = htmlspecialchars($g);
                            $selected = $entry['gatunek'] === $g ? 'selected' : '';
                            echo "<option value='$safe_g' $selected>$safe_g</option>";
                        }
                        ?>
                    </select>
                </label>
            </div>
            
            <div class="form-group">
                <label>Waga (kg):
                    <input type="number" name="waga" 
                           step="0.01" min="0.01" max="10000"
                           value="<?= htmlspecialchars($entry['waga']) ?>" 
                           required>
                </label>
            </div>

            <div class="form-group">
                <label>Zdjęcie (opcjonalnie):
                    <input type="file" name="obrazek" accept="image/png, image/jpeg">
                    <?php if (!empty($entry['obrazek'])): ?>
                        <div class="current-image">
                            <p>Aktualne zdjęcie:</p>
                            <img src="data:image/png;base64,<?= 
                                base64_encode($entry['obrazek']) 
                            ?>" alt="Aktualne zdjęcie">
                        </div>
                    <?php endif; ?>
                </label>
            </div>
            
            <div class="form-group">
                <input type="submit" value="Zapisz zmiany" class="btn-submit">
                <a href="history_in_entry_page_user.php" class="btn-cancel">Anuluj</a>
            </div>
        </form>
    </div>
</body>
</html>
