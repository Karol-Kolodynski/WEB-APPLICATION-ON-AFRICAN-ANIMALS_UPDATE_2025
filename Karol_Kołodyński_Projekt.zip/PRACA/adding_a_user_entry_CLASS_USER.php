
<?php
set_time_limit(300);
session_start();

// Weryfikacja tokena CSRF
if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    die("Nieprawidłowy token CSRF");
}

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

// Konfiguracja bezpieczeństwa
ini_set('disable_functions', 'exec,shell_exec,system,passthru');
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// Funkcja do wysyłania e-maila
function sendEmailNotification($username, $authorEmail, $nazwa, $opis, $gatunek, $waga, $obrazek_zawartosc, $obrazek_typ, $connection) {
    $mail = new PHPMailer(true);

    try {
        // Konfiguracja SMTP z środowiska systemowego
        $mail->isSMTP();
        $mail->Host = getenv('smtp.gmail.com');
        $mail->SMTPAuth = true;
        $mail->Username = getenv('afrykablog1@gmail.com');
        $mail->Password = getenv('jopq wujs maht xkxm');
        $mail->SMTPSecure = 'ssl';
        $mail->Port = 465;
        $mail->setFrom(getenv('afrykablog1@gmail.com'));

        $mail->addAddress($authorEmail);
        $mail->isHTML(true);
        $mail->Subject = htmlspecialchars("$username: dodałeś wpis", ENT_QUOTES, 'UTF-8');

        // Bezpieczne formatowanie treści
        $mail->Body = sprintf(
            '<p>Dodałeś nowy wpis:</p>
            <p>Nazwa zwierzęcia: %s</p>
            <p>Opis treści: %s</p>
            <p>Rodzaj gatunku: %s</p>
            <p>Waga: %s</p>',
            htmlspecialchars($nazwa, ENT_QUOTES, 'UTF-8'),
            htmlspecialchars($opis, ENT_QUOTES, 'UTF-8'),
            htmlspecialchars($gatunek, ENT_QUOTES, 'UTF-8'),
            htmlspecialchars($waga, ENT_QUOTES, 'UTF-8')
        );

        if (!empty($obrazek_zawartosc)) {
            $mail->addStringAttachment(
                $obrazek_zawartosc,
                sprintf("obrazek.%s", htmlspecialchars($obrazek_typ, ENT_QUOTES, 'UTF-8'))
            );
        }

        $mail->CharSet = 'UTF-8';
        $mail->Encoding = 'base64';
        $mail->setLanguage('pl');

        // Bezpieczne zapytanie SQL
        $notification_query = "SELECT notification_turn FROM rejestracjatesy WHERE username = ?";
        $stmt = mysqli_prepare($connection, $notification_query);
        mysqli_stmt_bind_param($stmt, "s", $username);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_bind_result($stmt, $notification_turn);
        mysqli_stmt_fetch($stmt);
        mysqli_stmt_close($stmt);

        if ($notification_turn) {
            $mail->send();
        }
    } catch (Exception $e) {
        error_log("Błąd wysyłki e-maila: " . $mail->ErrorInfo);
    }
}

// Sprawdzenie sesji użytkownika
if (!isset($_SESSION['user']) || empty($_SESSION['user'])) {
    header("Location: login_page.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanityzacja danych wejściowych
    $nazwa = filter_input(INPUT_POST, 'nazwa', FILTER_SANITIZE_STRING);
    $opis = filter_input(INPUT_POST, 'opis', FILTER_SANITIZE_STRING);
    $gatunek = filter_input(INPUT_POST, 'gatunek', FILTER_SANITIZE_STRING);
    $waga = filter_input(INPUT_POST, 'waga', FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
    $username = $_SESSION['user'];
    $author = $_SESSION['user']; // Pobieramy z sesji zamiast z POST

    // Walidacja wag
    if ($waga <= 0 || $waga > 10000) {
        $_SESSION['error'] = "Nieprawidłowa wartość wagi";
        header("Location: mainpage_user.php");
        exit();
    }

    if ($_FILES['obrazek']['error'] === UPLOAD_ERR_OK) {
        // Bezpieczna obsługa plików
        $max_file_size = 2 * 1024 * 1024;
        $allowed_extensions = ['png'];
        $file_extension = strtolower(pathinfo($_FILES['obrazek']['name'], PATHINFO_EXTENSION));
        
        // Dokładna weryfikacja MIME type
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime_type = finfo_file($finfo, $_FILES['obrazek']['tmp_name']);
        finfo_close($finfo);

        $allowed_mime_types = ['image/png'];

        if ($_FILES['obrazek']['size'] > $max_file_size) {
            $_SESSION['error'] = "Zdjęcie jest za duże. Maksymalny rozmiar to 2 MB.";
            header("Location: mainpage_user.php");
            exit();
        }

        if (!in_array($file_extension, $allowed_extensions) || !in_array($mime_type, $allowed_mime_types)) {
            $_SESSION['error'] = "Akceptowane są tylko pliki PNG.";
            header("Location: mainpage_user.php");
            exit();
        }

        // Bezpieczne odczytanie zawartości
        $obrazek_zawartosc = file_get_contents($_FILES['obrazek']['tmp_name']);
        if ($obrazek_zawartosc === false) {
            $_SESSION['error'] = "Błąd odczytu pliku";
            header("Location: mainpage_user.php");
            exit();
        }

        // Połączenie z bazą danych z obsługą błędów
        $connection = mysqli_connect("localhost", "root", "", "afryka_blog");
        if (!$connection) {
            error_log("Błąd połączenia z bazą: " . mysqli_connect_error());
            $_SESSION['error'] = "Błąd systemowy";
            header("Location: mainpage_user.php");
            exit();
        }

        // Transakcja dla bezpieczeństwa
        mysqli_begin_transaction($connection);
        try {
            $query = "INSERT INTO wpisy (nazwa, opis, obrazek, gatunek, waga, author, data_wyslania) 
                      VALUES (?, ?, ?, ?, ?, ?, NOW())";

            $stmt = mysqli_prepare($connection, $query);
            mysqli_stmt_bind_param($stmt, "ssssds", $nazwa, $opis, $obrazek_zawartosc, $gatunek, $waga, $author);

            if (!mysqli_stmt_execute($stmt)) {
                throw new Exception("Błąd wykonania zapytania");
            }

            // Pobieranie emaila
            $queryAuthorEmail = "SELECT email FROM rejestracjatesy WHERE username = ?";
            $stmtAuthorEmail = mysqli_prepare($connection, $queryAuthorEmail);
            mysqli_stmt_bind_param($stmtAuthorEmail, "s", $author);
            mysqli_stmt_execute($stmtAuthorEmail);
            mysqli_stmt_bind_result($stmtAuthorEmail, $authorEmail);
            mysqli_stmt_fetch($stmtAuthorEmail);
            mysqli_stmt_close($stmtAuthorEmail);

            if (empty($authorEmail)) {
                throw new Exception("Brak adresu email");
            }

            sendEmailNotification($username, $authorEmail, $nazwa, $opis, $gatunek, $waga, $obrazek_zawartosc, $file_extension, $connection);

            mysqli_commit($connection);
            $_SESSION['success'] = "Wpis został dodany pomyślnie!";
        } catch (Exception $e) {
            mysqli_rollback($connection);
            error_log("Błąd transakcji: " . $e->getMessage());
            $_SESSION['error'] = "Nie udało się dodać wpisu";
        } finally {
            mysqli_close($connection);
        }
    } else {
        $_SESSION['error'] = "Błąd podczas przesyłania obrazka";
    }
} else {
    $_SESSION['error'] = "Nieprawidłowe żądanie";
}

header("Location: mainpage_user.php");
exit();
?>