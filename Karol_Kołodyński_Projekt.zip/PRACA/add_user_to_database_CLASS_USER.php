<?php
session_start(); // Rozpoczęcie sesji

// Pobieranie danych z formularza
$username = isset($_POST["username"]) ? trim($_POST["username"]) : ''; // Pobranie nazwy użytkownika
$email = isset($_POST["email"]) ? trim($_POST["email"]) : ''; // Pobranie adresu e-mail
$password = isset($_POST['passwordd']) ? $_POST['passwordd'] : ''; // Pobranie hasła
$user_role = 'user'; // Domyślna rola dla nowego użytkownika

// Dołączenie bibliotek PHPMailer
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

// **✅ 1. Walidacja danych wejściowych**

// Walidacja nazwy użytkownika
if (!preg_match('/^[a-zA-Z0-9]{4,20}$/', $username)) {
    $_SESSION['error'] = "Nazwa użytkownika może zawierać tylko litery i cyfry (4-20 znaków).";
    header("Location: create_account_page.php");
    exit();
}

// Walidacja hasła
function isStrongPassword($password) {
    return strlen($password) >= 8 &&
           preg_match('/[a-z]/', $password) &&
           preg_match('/[A-Z]/', $password) &&
           preg_match('/\d/', $password) &&
           preg_match('/[\W]/', $password); // Przynajmniej jeden znak specjalny
}

if (!isStrongPassword($password)) {
    $_SESSION['error'] = "Hasło musi mieć min. 8 znaków, zawierać 1 dużą literę, 1 małą literę, 1 cyfrę i 1 znak specjalny.";
    header("Location: create_account_page.php");
    exit();
}

// Walidacja e-maila
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $_SESSION['error'] = "Nieprawidłowy format adresu e-mail.";
    header("Location: create_account_page.php");
    exit();
}

// **✅ 2. Sprawdzenie reCAPTCHA**
if (!isset($_POST['g-recaptcha-response']) || empty($_POST['g-recaptcha-response'])) {
    $_SESSION['error'] = "Proszę potwierdzić, że jesteś człowiekiem.";
    header("Location: create_account_page.php");
    exit();
}

$recaptcha_response = $_POST['g-recaptcha-response'];
$secret_key = "6LekCgkpAAAAAATqsPtkWKNlEyTsYpygskV-FAfI";
$check = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret=' . $secret_key . '&response=' . $recaptcha_response);
$answer = json_decode($check);

if (!$answer->success) {
    $_SESSION['error'] = "Błąd weryfikacji reCAPTCHA.";
    header("Location: create_account_page.php");
    exit();
}

// **✅ 3. Połączenie z bazą danych**
$connection = new mysqli("localhost", "root", "", "afryka_blog");
if ($connection->connect_error) {
    $_SESSION['error'] = "Błąd połączenia z bazą danych.";
    header("Location: create_account_page.php");
    exit();
}

// Oczyszczanie danych wejściowych
$username = mysqli_real_escape_string($connection, $username);
$email = mysqli_real_escape_string($connection, $email);

// Sprawdzenie, czy użytkownik już istnieje
$check_query = "SELECT * FROM rejestracjatesy WHERE username='$username'";
$result = mysqli_query($connection, $check_query);
if (mysqli_num_rows($result) > 0) {
    $_SESSION['error'] = "Użytkownik o nazwie '$username' już istnieje.";
    header("Location: create_account_page.php");
    exit();
}

// Sprawdzenie, czy email już istnieje
$check_email_query = "SELECT * FROM rejestracjatesy WHERE email='$email'";
$result_email = mysqli_query($connection, $check_email_query);
if (mysqli_num_rows($result_email) > 0) {
    $_SESSION['error'] = "Adres e-mail '$email' jest już zajęty.";
    header("Location: create_account_page.php");
    exit();
}

// **✅ 4. Hashowanie hasła**
$hashed_password = password_hash($password, PASSWORD_BCRYPT);

// **✅ 5. Zabezpieczenie przed XXE i zapis do XML**
libxml_disable_entity_loader(true); // Blokowanie XXE

$xml_file = 'user_data.xml';
if (!file_exists($xml_file)) {
    file_put_contents($xml_file, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<users>\n</users>");
}

$xml_content = file_get_contents($xml_file);
$xml = simplexml_load_string($xml_content, 'SimpleXMLElement', LIBXML_NOENT | LIBXML_DTDLOAD);

if ($xml === false) {
    $_SESSION['error'] = "Błąd parsowania XML. Możliwy atak XXE!";
    header("Location: create_account_page.php");
    exit();
}

$new_user = $xml->addChild('user');
$new_user->addChild('username', htmlspecialchars($username, ENT_XML1, 'UTF-8'));
$new_user->addChild('password', htmlspecialchars($hashed_password, ENT_XML1, 'UTF-8'));
$new_user->addChild('role', htmlspecialchars($user_role, ENT_XML1, 'UTF-8'));
$new_user->addChild('email', htmlspecialchars($email, ENT_XML1, 'UTF-8'));
$xml->asXML($xml_file);

// **✅ 6. Dodanie użytkownika do bazy danych**
$stmt = $connection->prepare("INSERT INTO rejestracjatesy (username, passwordd, email, user_role) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssss", $username, $hashed_password, $email, $user_role);
if ($stmt->execute()) {
    $_SESSION['user'] = $username;

    // **✅ 7. Wysyłanie e-maila powitalnego**
    function sendLoginNotification($user_email, $username) {
        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'afrykablog1@gmail.com';
            $mail->Password = 'jopq wujs maht xkxm';
            $mail->SMTPSecure = 'ssl';
            $mail->Port = 465;
            $mail->setFrom('afrykablog1@gmail.com', 'Afryka Blog');
            $mail->addAddress($user_email);
            $mail->isHTML(true);
            $mail->Subject = "Witamy nowego użytkownika - $username";
            $mail->Body = "<p><strong>Witamy na stronie Afryka Blog</strong></p><p>Twoja nazwa użytkownika: $username</p><p>Twój email: $user_email</p>";
            $mail->send();
        } catch (Exception $e) {
            $_SESSION['error'] = "Błąd wysyłania e-maila: {$mail->ErrorInfo}";
        }
    }

    sendLoginNotification($email, $username);
    header("Location: mainpage_user.php");
} else {
    $_SESSION['error'] = "Błąd podczas dodawania użytkownika.";
    header("Location: create_account_page.php");
    exit();
}
?>