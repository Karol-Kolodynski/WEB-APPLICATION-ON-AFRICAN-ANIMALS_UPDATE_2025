<?php
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure', 1);
ini_set('session.use_only_cookies', 1);

// Nagłówki bezpieczeństwa
header("Cache-Control: no-store, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: Fri, 01 Jan 1990 00:00:00 GMT");
header("Content-Security-Policy: default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'");

session_start();

// Konfiguracja bezpieczeństwa
define('ALLOWED_IMAGE_DOMAINS', ['trusted-cdn.com', 'public-images.example.com']); // Dostosuj do swoich potrzeb
define('MAX_IMAGE_SIZE', 2 * 1024 * 1024); // 2MB

if (!isset($_SESSION['user']) || empty($_SESSION['user']) || !is_string($_SESSION['user'])) {
    header("Location: login_page.php");
    exit();
}

$connection = new mysqli("localhost", "root", "", "afryka_blog");
if ($connection->connect_error) {
    die("Błąd połączenia: " . htmlspecialchars($connection->connect_error));
}

$username = $_SESSION['user'];
if (!preg_match('/^[a-zA-Z0-9_-]+$/', $username)) {
    die("Nieprawidłowa nazwa użytkownika!");
}

// Funkcja bezpieczeństwa przeciwko SSRF
function isAllowedImageHost($host) {
    $ip = gethostbyname($host);
    
    // Blokuj adresy prywatne i localhost
    $privateRanges = [
        '10.0.0.0/8',
        '172.16.0.0/12',
        '192.168.0.0/16',
        '127.0.0.0/8',
        '::1'
    ];
    
    foreach ($privateRanges as $range) {
        if (ip_in_range($ip, $range)) {
            return false;
        }
    }
    
    return in_array($host, ALLOWED_IMAGE_DOMAINS);
}

function ip_in_range($ip, $range) {
    list($subnet, $mask) = explode('/', $range);
    $ip = ip2long($ip);
    $subnet = ip2long($subnet);
    $mask = -1 << (32 - $mask);
    return ($ip & $mask) === ($subnet & $mask);
}

// Pobierz dane użytkownika
$query = "SELECT notification_turn, custom_greeting, message_prefs, custom_css_path, profile_image 
          FROM rejestracjatesy 
          WHERE username = ?";
$stmt = $connection->prepare($query);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

$current_notification_turn = $row['notification_turn'] ?? 0;
$current_greeting = htmlspecialchars($row['custom_greeting'] ?? '', ENT_QUOTES, 'UTF-8');
$message_prefs = json_decode($row['message_prefs'] ?? '[]', true);
$current_css = htmlspecialchars($row['custom_css_path'] ?? '', ENT_QUOTES, 'UTF-8');
$current_profile_image = htmlspecialchars($row['profile_image'] ?? '', ENT_QUOTES, 'UTF-8');

$stmt->close();
$connection->close();

// Walidacja CSS
$css_link = '';
if (!empty($current_css)) {
    $css_file = basename($current_css);
    if (preg_match('/^[a-zA-Z0-9_-]+\.css$/', $css_file)) {
        $v = $_SESSION['css_version'] ?? hash('crc32', filemtime($current_css));
        $css_link = '<link rel="stylesheet" href="' . htmlspecialchars($current_css, ENT_QUOTES, 'UTF-8') . '?v=' . $v . '">';
    }
}
?>

<!DOCTYPE html>
<html lang="pl-PL">
<head>
    <title>Blog o zwierzętach afrykańskich</title>
    <meta charset="UTF-8">
    <meta name="keywords" content="HTML, CSS, JavaScript">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/responsive_change_data_user.css">
    <?= $css_link; ?>

    <script>
        function toggleNotificationButton() {
            var notificationButton = document.getElementById('notificationButton');
            notificationButton.value = notificationButton.value === 'Wyłącz powiadomienia' 
                ? 'Włącz powiadomienia' 
                : 'Wyłącz powiadomienia';
        }
    </script>

<script>
        function validateImageURL(input) {
            const urlPattern = /^(https?:\/\/)([a-z0-9-]+\.)*([a-z0-9-]+\.[a-z]{2,})(\/[^\s]*)?$/i;
            const allowedExtensions = /\.(jpe?g|png|gif)$/i;
            
            if (!urlPattern.test(input.value) || !allowedExtensions.test(input.value)) {
                input.setCustomValidity('Nieprawidłowy format URL obrazu');
            } else {
                input.setCustomValidity('');
            }
        }
    </script>
     <style>
        
        .profile-image-preview {
            max-width: 200px;
            border-radius: 50%;
            margin: 10px 0;
        }
    </style>
</head>
<body>
    <nav class="navbar"> 
        <ul class="menu">
            <li><a href="mainpage.html">Wyloguj się</a></li>
            <li><a href="mainpage_user.php">Powrót na główną stronę</a></li>
        </ul>
    </nav>
    <div class="profile-image-container">
            <h2>Zdjęcie profilowe</h2>
            <?php if (!empty($current_profile_image)): ?>
  <img src="<?= $current_profile_image ?>?t=<?= filemtime($current_profile_image) ?>" 
       class="profile-image-preview" 
       alt="Aktualne zdjęcie">
<?php endif; ?>

<form action="upload_profile_image.php" method="post">
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'] ?? '') ?>">
    
    <div class="form-group">
        <label for="image_url">URL zdjęcia:</label>
        <input type="url" 
               id="image_url" 
               name="image_url" 
               required
               pattern="^(https?:\/\/)([a-z0-9-]+\.)*(trusted-cdn\.com|public-images\.example\.com)(\/[^\s]*)?$"
               placeholder="https://........jpg"
               oninput="validateImageURL(this)">
        <small>Dozwolone tylko URL</small>
    </div>

    <div class="form-group">
        <input type="submit" value="Aktualizuj zdjęcie" class="btn-primary">
    </div>
</form>
        </div>
    <div class="container">
        <h2>Zmień hasło</h2>
        <form action="change_password_CLASS_USER.php" method="post">
            <?php
            if (!empty($_SESSION['success'])) {
                echo "<div class='message success'>" . htmlspecialchars($_SESSION['success'], ENT_QUOTES, 'UTF-8') . "</div>";
                unset($_SESSION['success']);
            }
            if (!empty($_SESSION['error'])) {
                echo "<div class='message error'>" . htmlspecialchars($_SESSION['error'], ENT_QUOTES, 'UTF-8') . "</div>";
                unset($_SESSION['error']);
            }
            ?>
            <div class="form-group">
                <label for="current_password">Aktualne hasło</label>
                <input type="password" id="current_password" name="current_password" required>
            </div>
            <div class="form-group">
                <label for="new_password">Nowe hasło</label>
                <input type="password" id="new_password" name="new_password" required>
            </div>
            <div class="form-group">
                <input type="submit" value="Zapisz zmiany">
            </div>
        </form>
    </div>

    <div class="container">
        <h2>Personalizacja konta</h2>
        <form action="update_personalization_settings.php" method="post" enctype="multipart/form-data">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8'); ?>">

            <div class="form-group">
                <label for="custom_greeting">Spersonalizowane powitanie:</label>
                <input type="text" id="custom_greeting" name="custom_greeting" 
                       placeholder="np. Witaj, Miłośniku Kotów!"
                       value="<?= $current_greeting; ?>">
            </div>

            <div class="form-group">
                <label for="custom_template">Własny szablon CSS:</label>
                <input type="file" id="custom_template" name="custom_template" accept=".css">
                <small>Maksymalny rozmiar: 1MB, aktualny szablon: <?= $current_css ? basename($current_css) : 'brak'; ?></small>
            </div>

            <div class="form-group">
                <label>Preferencje wiadomości:</label><br>
                <?php foreach (['newsletter', 'updates', 'promotions'] as $option): ?>
                    <input type="checkbox" id="<?= $option; ?>" name="message_prefs[]" value="<?= $option; ?>" 
                           <?= in_array($option, $message_prefs) ? 'checked' : ''; ?>>
                    <label for="<?= $option; ?>"><?= ucfirst($option); ?></label><br>
                <?php endforeach; ?>
            </div>

            <div class="form-group">
                <input type="submit" value="Zapisz ustawienia">
            </div>
        </form>

        <form action="reset_theme.php" method="post">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8'); ?>">
            <button type="submit" class="reset-btn">
                <i class="fas fa-undo"></i> Resetuj motyw
            </button>
        </form>
    </div>

    <div class="container">
        <form action="change_notification_turn.php" method="post">
            <div class="form-group">
                <input type="submit" id="notificationButton" name="notification_turn" 
                       value="<?= $current_notification_turn ? 'Wyłącz powiadomienia' : 'Włącz powiadomienia'; ?>" 
                       onclick="toggleNotificationButton()">
            </div>
        </form>
    </div>
</body>
</html>
