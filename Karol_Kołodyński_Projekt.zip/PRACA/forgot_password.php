<?php
session_start();
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

// Mechanizm CSRF (Cross-Site Request Forgery)
// Generuje unikalny token dla każdej sesji, który musi być przesłany w formularzu
// Zapobiega wykonywaniu nieautoryzowanych akcji w imieniu użytkownika
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Połączenie z bazą danych
$connection = new mysqli("localhost", "root", "", "afryka_blog");
if ($connection->connect_error) {
    die("Błąd połączenia: " . $connection->connect_error);
}

// Ochrona przed atakami brute-force
// Liczy próby resetu hasła z danego IP w ostatniej godzinie
// Blokuje po 5 próbach, utrudniając automatyczne ataki
$ip = $_SERVER['REMOTE_ADDR'];
$stmt = $connection->prepare("SELECT COUNT(*) FROM login_attempts WHERE ip = ? AND timestamp > NOW() - INTERVAL 1 HOUR");
$stmt->bind_param("s", $ip);
$stmt->execute();
$result = $stmt->get_result();
$attempts = $result->fetch_array()[0];

if ($attempts > 5) {
    $_SESSION['error'] = "Zbyt wiele prób. Spróbuj ponownie za godzinę.";
    header("Location: forgot_password_page.php");
    exit();
}

// Obsługa formularza
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['email'], $_POST['csrf_token'])) {
    // Weryfikacja CSRF (Zabezpieczenie przed atakami CSRF)
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        die("Nieprawidłowa próba wysłania formularza");
    }

    $email = trim($_POST['email']);
    
    // Ochrona przed atakami czasowymi (Timing Attack)
    // Celowe losowe opóźnienie utrudniające wykrycie istnienia konta
    //0.5 sekundy (500 000) do 2 sekund (2 000 000).
    usleep(random_int(500000, 2000000));

    // Ochrona przed enumeracją kont
    // Jednolity komunikat niezależnie od istnienia emaila w systemie
    // Zapobiega wykryciu które adresy email są zarejestrowane    
    $stmt = $connection->prepare("SELECT id FROM rejestracjatesy WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    $_SESSION['success'] = "Jeśli email istnieje, otrzymasz link weryfikacyjny";
    
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $userId = $user['id'];

        // Generowanie tokenów (Bezpieczny link resetu)
        $urlToken = bin2hex(random_bytes(32)); // 256-bitowy token
        $code = random_int(100000, 999999); // 6-cyfrowy kod
        $expires = date("Y-m-d H:i:s", strtotime("+15 minutes")); // Ważność 15 minut

        // Bezpieczne przechowywanie tokenów
        // Powiązanie tokenu z IP użytkownika i limit czasu ważności
        $stmt = $connection->prepare("INSERT INTO password_resets (user_id, url_token, code, expires, ip) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("issss", $userId, $urlToken, $code, $expires, $ip);
        $stmt->execute();

        // Generowanie linku resetującego
        $host = $_SERVER['HTTP_HOST'];
        $resetLink = "http://$host/PRACA/reset_password.php?token=" . urlencode($urlToken);

        // Wysyłanie maila (Dwuetapowa weryfikacja)
        $mail = new PHPMailer(true);
        try {
            // Konfiguracja SMTP
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'afrykablog1@gmail.com';
            $mail->Password = 'jopq wujs maht xkxm';
            $mail->SMTPSecure = 'ssl';
            $mail->Port = 465;
            
            // Treść maila (Zabezpieczenie przed phishingiem)
            $mail->setFrom('afrykablog1@gmail.com', 'Afryka Blog');
            $mail->addAddress($email);
            $mail->isHTML(true);
            $mail->Subject = "Reset hasła - weryfikacja";
            $mail->Body = "
                <h3>Żądano resetu hasła z IP: $ip</h3>
                <p>Kliknij link aby kontynuować:</p>
                <a href='$resetLink'>ZWERYFIKUJ KONTO</a>
                <p>Kod weryfikacyjny: <b>$code</b></p>
                <p style='color:red'>Link jest ważny przez 15 minut!</p>
            ";
            $mail->send();
            
            // Logowanie próby (Zabezpieczenie przed atakami masowymi)
            $stmt = $connection->prepare("INSERT INTO login_attempts (ip, action_type) VALUES (?, 'reset_request')");
            $stmt->bind_param("s", $ip);
            $stmt->execute();
            
        } catch (Exception $e) {
            error_log("Błąd maila: ".$e->getMessage());
        }
    }
    
    header("Location: forgot_password_page.php");
    exit();
}