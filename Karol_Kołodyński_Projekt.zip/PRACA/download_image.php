<?php
session_start();

// Konfiguracja bezpieczeństwa
ini_set('disable_functions', 'exec,shell_exec,system,passthru');
error_reporting(0);
header("X-Content-Type-Options: nosniff");
header("X-Frame-Options: DENY");

// Sprawdzenie autoryzacji
if (!isset($_SESSION['user'])) {
    header("HTTP/1.1 403 Forbidden");
    exit();
}

try {
    $connection = mysqli_connect("localhost", "root", "", "afryka_blog");
    if (!$connection) {
        throw new Exception("Błąd połączenia z bazą danych");
    }

    // Walidacja i sanityzacja danych wejściowych
    $entry_id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
    if (!$entry_id || $entry_id <= 0) {
        throw new Exception("Nieprawidłowy identyfikator wpisu");
    }

    // Pobranie danych z użyciem prepared statements
    $query = "SELECT obrazek FROM wpisy WHERE id = ? AND author = ?";
    $stmt = mysqli_prepare($connection, $query);
    mysqli_stmt_bind_param($stmt, "is", $entry_id, $_SESSION['user']);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);

    if (mysqli_stmt_num_rows($stmt) === 0) {
        throw new Exception("Nie znaleziono obrazka");
    }

    mysqli_stmt_bind_result($stmt, $obrazek);
    mysqli_stmt_fetch($stmt);

    // Walidacja typu MIME
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime_type = $finfo->buffer($obrazek);
    $allowed_types = ['image/jpeg' => 'jpg', 'image/png' => 'png'];

    if (!array_key_exists($mime_type, $allowed_types)) {
        throw new Exception("Nieprawidłowy typ pliku");
    }

    // Bezpieczna nazwa pliku
    $safe_filename = preg_replace('/[^a-zA-Z0-9_-]/', '', $_SESSION['user']);
    $extension = $allowed_types[$mime_type];
    $filename = "zwierze_{$safe_filename}_{$entry_id}.{$extension}";

    // Nagłówki bezpieczeństwa
    header("Content-Type: {$mime_type}");
    header("Content-Disposition: attachment; filename=\"{$filename}\"");
    header("Content-Length: " . strlen($obrazek));
    
    echo $obrazek;
    exit();

} catch (Exception $e) {
    error_log("Błąd bezpieczeństwa: " . $e->getMessage());
    $_SESSION['error'] = "Wystąpił błąd podczas pobierania obrazu";
    header("Location: history_in_entry_page_user.php");
    exit();
}
?>