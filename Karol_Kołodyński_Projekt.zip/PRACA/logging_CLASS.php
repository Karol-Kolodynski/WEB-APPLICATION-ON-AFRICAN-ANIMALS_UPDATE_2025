<?php
session_start();
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Załadowanie bibliotek PHPMailer do obsługi e-maili
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

// Klucz reCAPTCHA do weryfikacji użytkownika
$secret_key = "6LekCgkpAAAAAATqsPtkWKNlEyTsYpygskV-FAfI"; 

if (isset($_POST['g-recaptcha-response'])) {
    $recaptcha_response = $_POST['g-recaptcha-response'];
    $check = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret=' . $secret_key . '&response=' . $recaptcha_response);
    $answer = json_decode($check);

    if ($answer->success) { 
        $email = $_POST["email"];
        $entered_password = $_POST["passwordd"];

        // Połączenie z bazą danych
        $connection = new mysqli("localhost", "root", "", "afryka_blog");

        if ($connection->connect_error) {
            die("Błąd połączenia: " . $connection->connect_error);
        }

        // **Zabezpieczenie przed SQL Injection**
        // Przygotowane zapytanie SQL chroni przed SQL Injection, ponieważ dane są przekazywane jako parametry
        $stmt = $connection->prepare("SELECT id, username, passwordd, user_role, failed_attempts, last_failed_attempt FROM rejestracjatesy WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->bind_result($user_id, $username, $stored_hashed_password, $user_role, $failed_attempts, $last_failed_attempt);
        $stmt->fetch();
        $stmt->close();

        if ($user_id) {
            // **Mechanizm ochrony przed Dictionary Attack**
            // Jeśli użytkownik 5 razy błędnie wpisze hasło, konto blokuje się na 15 minut
            if ($failed_attempts >= 5 && (time() - strtotime($last_failed_attempt) < 900)) {
                $_SESSION['error'] = "Konto zablokowane na 15 minut.";
                header("Location: login_page.php");
                exit();
            }

            // Weryfikacja poprawności hasła użytkownika
            if (password_verify($entered_password, $stored_hashed_password)) {
                $_SESSION['role_user'] = $user_role;

                // Reset liczby błędnych prób logowania po poprawnym logowaniu
                $stmt = $connection->prepare("UPDATE rejestracjatesy SET failed_attempts = 0 WHERE id = ?");
                $stmt->bind_param("i", $user_id);
                $stmt->execute();
                $stmt->close();

                // **System powiadamiania administratora**
                // Wysyłanie powiadomienia e-mail po zalogowaniu użytkownika
                if ($user_role == 'admin') {
                    $_SESSION['admin'] = $username;
                    sendLoginNotification($username, $email);
                    header("Location: mainpage_ADMIN.php");
                } elseif ($user_role == 'user') {
                    $_SESSION['user'] = $username;
                    sendLoginNotification($username, $email);
                    header("Location: mainpage_user.php");
                }
                exit();
            } else {
                // Aktualizacja liczby błędnych prób logowania
                $stmt = $connection->prepare("UPDATE rejestracjatesy SET failed_attempts = failed_attempts + 1, last_failed_attempt = NOW() WHERE id = ?");
                $stmt->bind_param("i", $user_id);
                $stmt->execute();
                $stmt->close();

                // Pobranie aktualnej liczby błędnych prób logowania
                $stmt = $connection->prepare("SELECT failed_attempts FROM rejestracjatesy WHERE id = ?");
                $stmt->bind_param("i", $user_id);
                $stmt->execute();
                $stmt->bind_result($failed_attempts);
                $stmt->fetch();
                $stmt->close();

                // **System powiadamiania administratora**
                // Wysłanie e-maila ostrzegającego użytkownika po 5 błędnych próbach logowania
                if ($failed_attempts == 4) {
                    sendAccountLockWarning($username, $email);
                }

                $_SESSION['error'] = "Niepoprawne dane logowania.";
                header("Location: login_page.php");
                exit();
            }
        } else {
            $_SESSION['error'] = "Niepoprawne dane logowania.";
            header("Location: login_page.php");
            exit();
        }
    } else {
        $_SESSION['error'] = "Proszę potwierdzić, że jesteś człowiekiem.";
        header("Location: login_page.php");
        exit();
    }
} else {
    $_SESSION['error'] = "Proszę potwierdzić, że jesteś człowiekiem.";
    header("Location: login_page.php");
    exit();
}

// **System powiadamiania administratora**
// Funkcja wysyłająca e-mail po zalogowaniu użytkownika
function sendLoginNotification($username, $user_email) {
    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'afrykablog1@gmail.com';
        $mail->Password = 'jopq wujs maht xkxm';
        $mail->SMTPSecure = 'ssl';
        $mail->Port = 465;
        $mail->setFrom('afrykablog1@gmail.com');

        $mail->addAddress($user_email);
        $mail->isHTML(true);
        $mail->Subject = "Powiadomienie o zalogowaniu - $username";
        $loginTime = date('Y-m-d H:i:s');
        $mail->Body = "$username, zalogowałeś się na swoje konto o godzinie $loginTime.";

        $mail->send();
    } catch (Exception $e) {
        error_log("Błąd wysyłania e-maila: " . $mail->ErrorInfo);
    }
}

// **System powiadamiania administratora**
// Funkcja wysyłająca ostrzeżenie użytkownikowi po 5 nieudanych logowaniach
function sendAccountLockWarning($username, $user_email) {
    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'afrykablog1@gmail.com';
        $mail->Password = 'jopq wujs maht xkxm';
        $mail->SMTPSecure = 'ssl';
        $mail->Port = 465;
        $mail->setFrom('afrykablog1@gmail.com', 'Administrator');

        $mail->addAddress($user_email);
        $mail->isHTML(true);
        $mail->Subject = "Ostrzeżenie: Twoje konto może zostać zablokowane";
        $lockTime = date('Y-m-d H:i:s', time() + 900); 
        $mail->Body = "
            <p>Witaj <b>$username</b>,</p>
            <p>Otrzymaliśmy <b>4 nieudanych prób logowania</b> na Twoje konto.</p>
            <p>Jeśli to nie Ty, natychmiast zmień hasło.</p>
            <p>Jeżeli wpiszesz błędne hasło ponownie, Twoje konto zostanie zablokowane do <b>$lockTime</b>.</p>
            <p><i>Administrator serwisu</i></p>
        ";
        $mail->send();
    } catch (Exception $e) {
        error_log("Błąd wysyłania e-maila ostrzegawczego: " . $mail->ErrorInfo);
    }
}
?>
