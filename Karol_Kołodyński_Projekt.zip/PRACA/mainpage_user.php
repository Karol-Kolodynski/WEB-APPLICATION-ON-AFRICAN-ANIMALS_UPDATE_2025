<?php
session_start();

// Sprawdzenie czy użytkownik jest zalogowany
if (!isset($_SESSION['user']) || empty($_SESSION['user']) || !is_string($_SESSION['user'])) {
    header("Location: login_page.php");
    exit();
}

// Generowanie tokena CSRF
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Walidacja i zabezpieczenie nazwy użytkownika
$username = $_SESSION['user'];
if (!ctype_alnum(str_replace(['-', '_'], '', $username))) {
    die("Błąd: Nieprawidłowa nazwa użytkownika!");
}

// Połączenie z bazą danych
$connection = new mysqli("localhost", "root", "", "afryka_blog");
if ($connection->connect_error) {
    die("Błąd połączenia: " . $connection->connect_error);
}

// Przygotowane zapytanie SQL dla bezpieczeństwa
$query = "SELECT custom_greeting, custom_css_path FROM rejestracjatesy WHERE username = ?";
$stmt = $connection->prepare($query);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

$custom_greeting = htmlspecialchars($row['custom_greeting'] ?? 'Witaj', ENT_QUOTES, 'UTF-8');
$custom_css = htmlspecialchars($row['custom_css_path'] ?? '', ENT_QUOTES, 'UTF-8');

// Sprawdzenie, czy ścieżka CSS jest poprawna
if (!empty($custom_css) && !preg_match('/^[a-zA-Z0-9_\-\/\.]+\.css$/', $custom_css)) {
    $custom_css = ''; // Resetowanie potencjalnie niebezpiecznej ścieżki
}

$stmt->close();
$connection->close();
?>

<!DOCTYPE html>
<html lang="pl-PL">
<head>
    <title>Blog o zwierzętach afrykańskich</title>
    <meta charset="UTF-8">
    <meta name="keywords" content="HTML, CSS, JavaScript">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/responsive_user.css">
    
    <?php if (!empty($custom_css)): ?>
        <link rel="stylesheet" href="<?php echo htmlspecialchars($custom_css, ENT_QUOTES, 'UTF-8'); ?>">
    <?php endif; ?>
</head>
<body>

    <nav class="navbar">
        <ul class="menu">
            <li><a href="mainpage.html">Wyloguj się</a></li>
        </ul>
        <ul class="menu">
            <li><a href="entries_from_users_page.php">Zobacz wpisy</a></li>
        </ul>
        <ul class="menu">
            <li><a href="history_in_entry_page_user.php">Historia wpisu</a></li>
        </ul>
        <ul class="menu">
            <li><a href="animal_search_page.php">Mapa Afryki</a></li>
        </ul>
        <ul class="menu">
            <li><a href="change_data_user_page.php">Edytuj konto</a></li>
        </ul>
    </nav>

    <div class="container">
        <h2><?php echo $custom_greeting . ' ' . htmlspecialchars($username, ENT_QUOTES, 'UTF-8'); ?></h2>
        
        <form action="adding_a_user_entry_CLASS_USER.php" method="post" enctype="multipart/form-data">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            
            <div class="form-group">
                <label for="nazwa">Nazwa zwierzęcia</label>
                <input type="text" id="nazwa" name="nazwa" required>
            </div>
            <div class="form-group">
                <label for="opis">Opis treści</label>
                <textarea id="opis" name="opis" rows="4" required></textarea>
            </div>
            <div class="form-group">
                <label for="obrazek">Dodaj obrazek</label>
                <input type="file" id="obrazek" name="obrazek" accept="image/png, image/jpeg" required>
            </div>
            <div class="form-group">
                <label for="gatunek">Rodzaj gatunku zwierzęcia</label>
                <select id="gatunek" name="gatunek" required>
                    <option value="Ssak">Ssak</option>
                    <option value="Ptak">Ptak</option>
                    <option value="Gad">Gad</option>
                    <option value="Płaz">Płaz</option>
                    <option value="Ryba">Ryba</option>
                    <option value="Stawonoga">Stawonoga</option>
                    <option value="Inny">Inny</option>
                </select>
            </div>
            <div class="form-group">
                <label for="waga">Waga (kg)</label>
                <input type="text" id="waga" name="waga" pattern="[0-9]+(\.[0-9]+)?" title="Wprowadź liczbę" required>
            </div>
            <input type="hidden" name="author" value="<?php echo htmlspecialchars($username, ENT_QUOTES, 'UTF-8'); ?>"> 
            
            <div class="form-group">
                <input type="submit" value="Dodaj">
            </div>
            <div class="form-group">
                <?php
                if (isset($_SESSION['success'])) {
                    echo "<p>" . htmlspecialchars($_SESSION['success'], ENT_QUOTES, 'UTF-8') . "</p>";
                    unset($_SESSION['success']);
                } elseif (isset($_SESSION['error'])) {
                    echo "<p>" . htmlspecialchars($_SESSION['error'], ENT_QUOTES, 'UTF-8') . "</p>";
                    unset($_SESSION['error']);
                }
                ?>
            </div>
        </form>
    </div>
</body>
</html>
