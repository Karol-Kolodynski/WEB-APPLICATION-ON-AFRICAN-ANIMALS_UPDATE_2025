<?php
session_start();

// Sprawdzenie czy użytkownik jest zalogowany
if (!isset($_SESSION['user']) || $_SESSION['user'] == "") {
    header("Location: login_page.php");
    exit();
}

// Weryfikacja tokena CSRF
if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    die("Błąd bezpieczeństwa: Nieprawidłowy token CSRF");
}

// Nawiązanie połączenia z bazą danych
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "afryka_blog";

$connection = mysqli_connect($servername, $username, $password, $dbname);

if (!$connection) {
    die("Błąd połączenia z bazą danych: " . mysqli_connect_error());
}
mysqli_set_charset($connection, "utf8mb4");

// Funkcja do zabezpieczenia przed SSTI (Server-Side Template Injection)
function sanitize_input($input) {
    // Usunięcie potencjalnych znaczników szablonowych typu {{ }}, {% %}, itp.
    return str_replace(['{{', '}}', '{%', '%}'], '', $input);
}

// Przetwarzanie danych formularza
$username = $_SESSION['user'];

// Zastosowanie funkcji zabezpieczającej przed SSTI
$custom_greeting = sanitize_input($_POST['custom_greeting'] ?? '');
$custom_greeting = mysqli_real_escape_string($connection, $custom_greeting);

// Preferencje wiadomości (tablica do JSON)
$message_prefs = isset($_POST['message_prefs']) ? json_encode($_POST['message_prefs']) : json_encode([]);

// Obsługa przesyłania pliku CSS
$upload_dir = "user_templates/";
$custom_css_path = null;

if ($_FILES['custom_template']['error'] === UPLOAD_ERR_OK) {
    $file = $_FILES['custom_template'];
    
    // Walidacja typu MIME
    $allowed_types = ['text/css', 'text/plain'];
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($file['tmp_name']);
    
    if (!in_array($mime, $allowed_types)) {
        $_SESSION['error'] = "Dozwolone są tylko pliki CSS";
        header("Location: change_data_user_page.php");
        exit();
    }
    
    // Walidacja rozmiaru pliku
    if ($file['size'] > 1048576) {
        $_SESSION['error'] = "Plik jest zbyt duży (maks. 1MB)";
        header("Location: change_data_user_page.php");
        exit();
    }
    
    // Generowanie unikalnej nazwy pliku
    $filename = $username . '_template_' . time() . '.css';
    $target_path = $upload_dir . $filename;
    
    // Utwórz folder jeśli nie istnieje
    if (!file_exists($upload_dir)) {
        mkdir($upload_dir, 0755, true);
    }
    
    if (move_uploaded_file($file['tmp_name'], $target_path)) {
        $custom_css_path = $target_path;
    } else {
        $_SESSION['error'] = "Błąd podczas przesyłania pliku";
        header("Location: change_data_user_page.php");
        exit();
    }
}

// Aktualizacja bazy danych z użyciem prepared statements
$sql = "UPDATE rejestracjatesy 
        SET custom_greeting = ?,
            message_prefs = ?"
        . ($custom_css_path ? ", custom_css_path = ?" : "") 
        . " WHERE username = ?";

$stmt = mysqli_prepare($connection, $sql);

if ($custom_css_path) {
    mysqli_stmt_bind_param($stmt, "ssss", $custom_greeting, $message_prefs, $custom_css_path, $username);
} else {
    mysqli_stmt_bind_param($stmt, "sss", $custom_greeting, $message_prefs, $username);
}

if (mysqli_stmt_execute($stmt)) {
    $_SESSION['success'] = "Ustawienia zostały zaktualizowane!";
} else {
    $_SESSION['error'] = "Błąd aktualizacji: " . mysqli_error($connection);
}

mysqli_stmt_close($stmt);
mysqli_close($connection);

header("Location: change_data_user_page.php");
exit();
