
<?php
// Ustawienia bezpieczeństwa dla ciasteczek sesyjnych
//Zabezpieczenie przed Stealing Cookies using XSS

session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => true,
    'httponly' => true,
    'samesite' => 'Strict'
]);
session_start();

// Sprawdza, czy dany administrator jest zalogowany
if (!isset($_SESSION['admin']) || $_SESSION['admin'] == "") {
    header("Location: login_page.php");
    exit();
}

// Załaduj klasy PHPMailer
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

//////////// Funkcja do wysyłania powiadomienia e-mail o usunięty WPIS
function sendEmailNotificationOnEntryDeletion($username, $userEmail, $nazwa, $opis, $gatunek, $waga, $data_wyslania, $reason) {
    $mail = new PHPMailer(true);

    // Sanityzacja danych wyjściowych
    //Zabezpieczenie przed Stored XSS
    $nazwa = htmlspecialchars($nazwa, ENT_QUOTES, 'UTF-8');
    $opis = htmlspecialchars($opis, ENT_QUOTES, 'UTF-8');
    $gatunek = htmlspecialchars($gatunek, ENT_QUOTES, 'UTF-8');
    $waga = htmlspecialchars($waga, ENT_QUOTES, 'UTF-8');
    $data_wyslania = htmlspecialchars($data_wyslania, ENT_QUOTES, 'UTF-8');
    $reason = htmlspecialchars($reason, ENT_QUOTES, 'UTF-8');

    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'afrykablog1@gmail.com';
    $mail->Password = 'jopq wujs maht xkxm';
    $mail->SMTPSecure = 'ssl';
    $mail->Port = 465;
    $mail->setFrom('afrykablog1@gmail.com');

    if (!empty($userEmail)) {
        $mail->addAddress($userEmail);
    } else {
        echo "Ostrzeżenie: Nieprawidłowy adres email autora, powiadomienie nie zostało wysłane.";
        return;
    }
    
    $mail->isHTML(true);
    $mail->Subject = "Twój wpis został usunięty";
    $mail->Body = "<p>Twój wpis został usunięty:</p>"
        . "<p>Nazwa zwierzęcia: $nazwa</p>"
        . "<p>Opis treści: $opis</p>"
        . "<p>Rodzaj gatunku zwierzęcia: $gatunek</p>"
        . "<p>Waga: $waga</p>"
        . "<p>Data wysłania: $data_wyslania</p>"
        . "<p>Powód usunięcia: $reason</p>";

    $mail->CharSet = 'UTF-8';
    $mail->Encoding = 'base64';
    $mail->setLanguage('pl');

    $mail->send();
}

///////////////////////////// Powiadomienie o usunięty komentarz
function sendEmailNotificationOnCommentDeletion($username, $userEmail, $komentarz, $data_dodania, $reason) {
    $mail = new PHPMailer(true);

    // Sanityzacja danych wyjściowych
    //Zabezpieczenie przed Stored XSS
    $komentarz = htmlspecialchars($komentarz, ENT_QUOTES, 'UTF-8');
    $data_dodania = htmlspecialchars($data_dodania, ENT_QUOTES, 'UTF-8');
    $reason = htmlspecialchars($reason, ENT_QUOTES, 'UTF-8');

    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'afrykablog1@gmail.com';
    $mail->Password = 'jopq wujs maht xkxm';
    $mail->SMTPSecure = 'ssl';
    $mail->Port = 465;
    $mail->setFrom('afrykablog1@gmail.com');

    if (!empty($userEmail)) {
        $mail->addAddress($userEmail);
    } else {
        echo "Ostrzeżenie: Nieprawidłowy adres email autora, powiadomienie nie zostało wysłane.";
        return;
    }
    
    $mail->isHTML(true);
    $mail->Subject = "Twój komentarz został usunięty";
    $mail->Body = "<p>Twój komentarz został usunięty:</p>"
        . "<p>Twój komentarz: $komentarz</p>"
        . "<p>Data wysłania tego komentarza: $data_dodania</p>"
        . "<p>Powód usunięcia: $reason</p>";

    $mail->CharSet = 'UTF-8';
    $mail->Encoding = 'base64';
    $mail->setLanguage('pl');

    $mail->send();
}

//////////////////////////////////////////////////////////
function sendEmailNotificationOnUserDeletion($username, $userEmail, $passwordd, $reason) {
    $mail = new PHPMailer(true);

    // Sanityzacja danych wyjściowych
    //Zabezpieczenie przed Stored XSS
    $username = htmlspecialchars($username, ENT_QUOTES, 'UTF-8');
    $userEmail = htmlspecialchars($userEmail, ENT_QUOTES, 'UTF-8');
    $passwordd = htmlspecialchars($passwordd, ENT_QUOTES, 'UTF-8');
    $reason = htmlspecialchars($reason, ENT_QUOTES, 'UTF-8');

    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'afrykablog1@gmail.com';
    $mail->Password = 'jopq wujs maht xkxm';
    $mail->SMTPSecure = 'ssl';
    $mail->Port = 465;
    $mail->setFrom('afrykablog1@gmail.com');

    $mail->addAddress($userEmail);
    $mail->isHTML(true);
    $mail->Subject = "Zostałeś usunięty z Afryki blog!";
    $mail->Body = "<p>Zostałeś usunięty z Afryki blog!</p>"
        . "<p>Nazwa użytkownika: $username</p>"
        . "<p>Adres e-mail: $userEmail</p>"
        . "<p>Hasło: $passwordd</p>"
        . "<p>Powód usunięcia: $reason</p>";

    $mail->CharSet = 'UTF-8';
    $mail->Encoding = 'base64';
    $mail->setLanguage('pl');

    $mail->send();
}

/////////////////////////
// Obsługa usuwania komentarza
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['comment_id'])) {
    $comment_id = (int)$_POST['comment_id'];

    //Zabezpieczenie przed Stored XSS
    $reason = isset($_POST['reason']) ? htmlspecialchars($_POST['reason'], ENT_QUOTES, 'UTF-8') : '';
    
    $connection = mysqli_connect("localhost", "root", "", "afryka_blog");
    if (!$connection) {
        die("Błąd połączenia z bazą danych: " . mysqli_connect_error());
    }
    
    // Pobierz autora komentarza
    //Zabezpieczenie przed Code Injection
    $queryEntryAuthor = "SELECT author FROM komentarze_pod_wpisem WHERE id = ?";
    $stmtEntryAuthor = mysqli_prepare($connection, $queryEntryAuthor);
    mysqli_stmt_bind_param($stmtEntryAuthor, "i", $comment_id);



    mysqli_stmt_execute($stmtEntryAuthor);
    mysqli_stmt_bind_result($stmtEntryAuthor, $entryAuthor);
    mysqli_stmt_fetch($stmtEntryAuthor);
    mysqli_stmt_close($stmtEntryAuthor);

    // Pobierz szczegóły komentarza
    $queryEntryDetails = "SELECT komentarz, data_dodania FROM komentarze_pod_wpisem WHERE id = ?";
    $stmtEntryDetails = mysqli_prepare($connection, $queryEntryDetails);
    mysqli_stmt_bind_param($stmtEntryDetails, "i", $comment_id);
    mysqli_stmt_execute($stmtEntryDetails);
    mysqli_stmt_bind_result($stmtEntryDetails, $komentarz, $data_dodania);
    mysqli_stmt_fetch($stmtEntryDetails);
    mysqli_stmt_close($stmtEntryDetails);

    // Usuń komentarz
    $queryDeleteEntry = "DELETE FROM komentarze_pod_wpisem WHERE id = ?";
    $stmtDeleteEntry = mysqli_prepare($connection, $queryDeleteEntry);
    mysqli_stmt_bind_param($stmtDeleteEntry, "i", $comment_id);

    if (mysqli_stmt_execute($stmtDeleteEntry)) {
        $_SESSION['success'] = "Komentarz został pomyślnie usunięty.";

        // Pobierz email autora
        $queryEntryAuthorEmail = "SELECT email FROM rejestracjatesy WHERE username = ?";
        $stmtEntryAuthorEmail = mysqli_prepare($connection, $queryEntryAuthorEmail);
        mysqli_stmt_bind_param($stmtEntryAuthorEmail, "s", $entryAuthor);
        mysqli_stmt_execute($stmtEntryAuthorEmail);
        mysqli_stmt_bind_result($stmtEntryAuthorEmail, $entryAuthorEmail);
        mysqli_stmt_fetch($stmtEntryAuthorEmail);
        mysqli_stmt_close($stmtEntryAuthorEmail);

        sendEmailNotificationOnCommentDeletion($entryAuthor, $entryAuthorEmail, $komentarz, $data_dodania, $reason);    
    } else {
        $_SESSION['error'] = "Nie udało się usunąć komentarza.";
    }

    mysqli_close($connection);
    header("Location: mainpage_ADMIN.php");
    exit();
}

/////////////////////// Obsługa usuwania wpisu
elseif ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['entry_id'])) {
    $entry_id = (int)$_POST['entry_id'];

    //Zabezpieczenie przed Stored XSS
    $reason = isset($_POST['reason']) ? htmlspecialchars($_POST['reason'], ENT_QUOTES, 'UTF-8') : '';
    
    $connection = mysqli_connect("localhost", "root", "", "afryka_blog");
    if (!$connection) {
        die("Błąd połączenia z bazą danych: " . mysqli_connect_error());
    }
    
    // Pobierz autora wpisu
    //Zabezpieczenie przed Code Injection
    $queryEntryAuthor = "SELECT author FROM wpisy WHERE id = ?";
    $stmtEntryAuthor = mysqli_prepare($connection, $queryEntryAuthor);
    mysqli_stmt_bind_param($stmtEntryAuthor, "i", $entry_id);
    mysqli_stmt_execute($stmtEntryAuthor);
    mysqli_stmt_bind_result($stmtEntryAuthor, $entryAuthor);
    mysqli_stmt_fetch($stmtEntryAuthor);
    mysqli_stmt_close($stmtEntryAuthor);

    // Pobierz szczegóły wpisu
    $queryEntryDetails = "SELECT nazwa, opis, gatunek, waga, data_wyslania FROM wpisy WHERE id = ?";
    $stmtEntryDetails = mysqli_prepare($connection, $queryEntryDetails);
    mysqli_stmt_bind_param($stmtEntryDetails, "i", $entry_id);
    mysqli_stmt_execute($stmtEntryDetails);
    mysqli_stmt_bind_result($stmtEntryDetails, $nazwa, $opis, $gatunek, $waga, $data_wyslania);
    mysqli_stmt_fetch($stmtEntryDetails);
    mysqli_stmt_close($stmtEntryDetails);

    // Usuń wpis
    $queryDeleteEntry = "DELETE FROM wpisy WHERE id = ?";
    $stmtDeleteEntry = mysqli_prepare($connection, $queryDeleteEntry);
    mysqli_stmt_bind_param($stmtDeleteEntry, "i", $entry_id);

    if (mysqli_stmt_execute($stmtDeleteEntry)) {
        $_SESSION['success'] = "Wpis został pomyślnie usunięty.";

        // Pobierz email autora
        //Zabezpieczenie przed Code Injection
        $queryEntryAuthorEmail = "SELECT email FROM rejestracjatesy WHERE username = ?";
        $stmtEntryAuthorEmail = mysqli_prepare($connection, $queryEntryAuthorEmail);
        mysqli_stmt_bind_param($stmtEntryAuthorEmail, "s", $entryAuthor);
        mysqli_stmt_execute($stmtEntryAuthorEmail);
        mysqli_stmt_bind_result($stmtEntryAuthorEmail, $entryAuthorEmail);
        mysqli_stmt_fetch($stmtEntryAuthorEmail);
        mysqli_stmt_close($stmtEntryAuthorEmail);

        sendEmailNotificationOnEntryDeletion($entryAuthor, $entryAuthorEmail, $nazwa, $opis, $gatunek, $waga, $data_wyslania, $reason);    
    } else {
        $_SESSION['error'] = "Nie udało się usunąć wpisu.";
    }

    mysqli_close($connection);
    header("Location: mainpage_ADMIN.php");
    exit();
} 

/////////////////////// Obsługa usuwania użytkownika
elseif ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["delete_user"]) && isset($_POST["user_id"])) {
    $connection = mysqli_connect("localhost", "root", "", "afryka_blog");
    if (!$connection) {
        die("Błąd połączenia z bazą danych: " . mysqli_connect_error());
    }

    $user_id = (int)$_POST["user_id"];
    //Zabezpieczenie przed Stored XSS
    $reason = isset($_POST['reason']) ? htmlspecialchars($_POST['reason'], ENT_QUOTES, 'UTF-8') : '';

    // Pobierz informacje o użytkowniku
    $queryUserInfo = "SELECT username, email, passwordd FROM rejestracjatesy WHERE id = ?";
    $stmt = mysqli_prepare($connection, $queryUserInfo);
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);
    $resultUserInfo = mysqli_stmt_get_result($stmt);

    if ($resultUserInfo && mysqli_num_rows($resultUserInfo) > 0) {
        $userInfo = mysqli_fetch_assoc($resultUserInfo);

        // Usuń użytkownika
        $queryDeleteUser = "DELETE FROM rejestracjatesy WHERE id = ?";
        $stmtDelete = mysqli_prepare($connection, $queryDeleteUser);
        mysqli_stmt_bind_param($stmtDelete, "i", $user_id);

        if (mysqli_stmt_execute($stmtDelete)) {
            $_SESSION['success'] = "Użytkownik został pomyślnie usunięty.";
            sendEmailNotificationOnUserDeletion(
                $userInfo['username'],
                $userInfo['email'],
                $userInfo['passwordd'],
                $reason
            );
        } else {
            $_SESSION['error'] = "Błąd podczas usuwania użytkownika.";
        }
    } else {
        $_SESSION['error'] = "Nie znaleziono użytkownika.";
    }

    mysqli_close($connection);
    header("Location: list_a_users_ADMIN_page.php");
    exit();
}

else {
    $_SESSION['error'] = "Nieprawidłowe żądanie.";
    header("Location: mainpage_ADMIN.php");
    exit();
}
?>