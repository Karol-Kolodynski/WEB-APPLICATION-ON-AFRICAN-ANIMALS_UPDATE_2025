<?php
session_start();

// Konfiguracja bezpieczeństwa
ini_set('disable_functions', 'exec,shell_exec,system,passthru');
error_reporting(E_ALL);
ini_set('display_errors', 0);
header("X-XSS-Protection: 1; mode=block");
header("X-Content-Type-Options: nosniff");

// Weryfikacja sesji
if (!isset($_SESSION['user']) || empty($_SESSION['user'])) {
    header("Location: login_page.php");
    exit();
}

// Połączenie z bazą danych
$connection = mysqli_connect("localhost", "root", "", "afryka_blog");
$username = htmlspecialchars($_SESSION['user'], ENT_QUOTES, 'UTF-8');

// Zabezpieczenie przed SSTI: Sanitizacja ścieżki CSS


// Przygotowane zapytanie SQL dla bezpieczeństwa
$query = "SELECT custom_greeting, custom_css_path FROM rejestracjatesy WHERE username = ?";
$stmt = $connection->prepare($query);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

$custom_greeting = htmlspecialchars($row['custom_greeting'] ?? 'Witaj', ENT_QUOTES, 'UTF-8');
$custom_css = htmlspecialchars($row['custom_css_path'] ?? '', ENT_QUOTES, 'UTF-8');

// Weryfikacja i filtracja zmiennych GET
$selectedGenre = isset($_GET['genre']) ? htmlspecialchars($_GET['genre'], ENT_QUOTES, 'UTF-8') : 'all';
$selectedOrder = isset($_GET['order']) ? htmlspecialchars($_GET['order'], ENT_QUOTES, 'UTF-8') : 'desc';

// Obsługa usuwania wpisu
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_entry'])) {
    // Weryfikacja CSRF
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die("Nieprawidłowy token CSRF");
    }

    $connection = mysqli_connect("localhost", "root", "", "afryka_blog");
    if (!$connection) die("Błąd połączenia: " . mysqli_connect_error());

    // Bezpieczne przygotowane zapytanie
    $entry_id = filter_input(INPUT_POST, 'entry_id', FILTER_VALIDATE_INT);
    if (!$entry_id) {
        $_SESSION['error'] = "Nieprawidłowy identyfikator wpisu";
        header("Location: history_in_entry_page_user.php");
        exit();
    }

    // Sprawdzenie uprawnień z użyciem prepared statements
    $check_query = "SELECT author FROM wpisy WHERE id = ?";
    $stmt = mysqli_prepare($connection, $check_query);
    mysqli_stmt_bind_param($stmt, "i", $entry_id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $db_author);
    mysqli_stmt_fetch($stmt);
    mysqli_stmt_close($stmt);

    if ($db_author === $username) {
        $delete_query = "DELETE FROM wpisy WHERE id = ?";
        $stmt = mysqli_prepare($connection, $delete_query);
        mysqli_stmt_bind_param($stmt, "i", $entry_id);
        
        if (mysqli_stmt_execute($stmt)) {
            $_SESSION['success'] = "Wpis został usunięty!";
        } else {
            $_SESSION['error'] = "Błąd podczas usuwania wpisu!";
        }
    } else {
        $_SESSION['error'] = "Nie masz uprawnień!";
    }
    mysqli_close($connection);
    header("Location: history_in_entry_page_user.php");
    exit();
}

// Połączenie z bazą danych
$connection = mysqli_connect("localhost", "root", "", "afryka_blog");
if (!$connection) die("Błąd połączenia: " . mysqli_connect_error());
?>

<!DOCTYPE html>
<html lang="pl-PL">
<head>

    <title>Blog o zwierzętach afrykańskich - wpisy od użytkowników</title>
    <meta charset="UTF-8">
    <meta name="keywords" content="HTML, CSS, JavaScript">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/responsive_user.css">
    <script>
        function confirmDelete(entryId) {
            return confirm("Czy na pewno chcesz usunąć wpis #" + entryId + "?");
        }
    </script>

<?php if (!empty($custom_css)): ?>
    <link rel="stylesheet" href="<?php echo $custom_css; ?>">
<?php endif; ?>
<style>
    .comment {
        display: flex;
        gap: 15px;
        margin: 15px 0;
        padding: 15px;
        background: #f8f9fa;
        border-radius: 10px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }

    .profile-image {
        width: 50px;
        height: 50px;
        border-radius: 50%;
        object-fit: cover;
        flex-shrink: 0;
        border: 2px solid #ddd;
    }

    .default-avatar {
        width: 50px;
        height: 50px;
        border-radius: 50%;
        background: #007bff;
        color: white;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: bold;
        flex-shrink: 0;
    }

    .comment-body {
        flex-grow: 1;
    }

    .comment-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 8px;
    }

    .comment-author {
        font-weight: 600;
        color: #333;
    }

    .comment-date {
        font-size: 0.85em;
        color: #666;
    }

    .comment-text {
        margin: 0;
        color: #444;
        line-height: 1.5;
    }
</style>
<script>
    function createDefaultAvatar(imgElement) {
        const div = document.createElement('div');
        div.className = 'default-avatar';
        const username = imgElement.alt.replace('Profil ', '');
        div.textContent = username.substring(0, 2).toUpperCase();
        return div;
    }
</script>
</head>

<body>
    <nav class="navbar">
        <ul class="menu">
            <li><a href="mainpage.html">Wyloguj się</a></li>
        </ul>
        <ul class="menu">
            <li><a href="mainpage_user.php">Powrót na główną stronę</a></li>
        </ul>
    </nav>

    <div class="container">
    <h2><?php echo $custom_greeting . ' ' . htmlspecialchars($_SESSION['user']); ?></h2>
    <div class="form-group">
            <?php
            if (isset($_SESSION['success'])) {
                echo "<p><strong>{$_SESSION['success']}</strong></p>";
                unset($_SESSION['success']);
            } elseif (isset($_SESSION['error'])) {
                echo "<p><strong>{$_SESSION['error']}</strong></p>";
                unset($_SESSION['error']);
            }
            ?>
        </div>

        <form method="get">
            <div class="form-group">
                <label for="genre">Wybierz gatunek:</label>
                <select name="genre" id="genre">
                    <option value="all" <?php echo ($selectedGenre == 'all') ? 'selected' : ''; ?>>Wszystkie</option>
                    <option value="Ssak" <?php echo ($selectedGenre == 'Ssak') ? 'selected' : ''; ?>>Ssak</option>
                    <option value="Ptak" <?php echo ($selectedGenre == 'Ptak') ? 'selected' : ''; ?>>Ptak</option>
                    <option value="Gad" <?php echo ($selectedGenre == 'Gad') ? 'selected' : ''; ?>>Gad</option>
                    <option value="Płaz" <?php echo ($selectedGenre == 'Płaz') ? 'selected' : ''; ?>>Płaz</option>
                    <option value="Ryba" <?php echo ($selectedGenre == 'Ryba') ? 'selected' : ''; ?>>Ryba</option>
                    <option value="Stawonoga" <?php echo ($selectedGenre == 'Stawonoga') ? 'selected' : ''; ?>>Stawonoga</option>
                    <option value="Inny" <?php echo ($selectedGenre == 'Inny') ? 'selected' : ''; ?>>Inny</option>
                </select>

                <label for="order">Sortuj według daty:</label>
                <select name="order" id="order">
                    <option value="desc" <?php echo ($selectedOrder == 'desc') ? 'selected' : ''; ?>>Najnowsze</option>
                    <option value="asc" <?php echo ($selectedOrder == 'asc') ? 'selected' : ''; ?>>Najstarsze</option>
                </select>
            </div>

            <div class="form-group">
                <input type="submit" value="Filtruj">
            </div>
        </form>

        <?php
        // Bezpieczne zapytanie z użyciem prepared statements
        $query = "SELECT * FROM wpisy WHERE author = ?";
        $params = [$username];
        $types = "s";

        if ($selectedGenre !== 'all') {
            $query .= " AND gatunek = ?";
            $params[] = $selectedGenre;
            $types .= "s";
        }

        $query .= " ORDER BY data_wyslania " . ($selectedOrder === 'asc' ? 'ASC' : 'DESC');

        $stmt = mysqli_prepare($connection, $query);
        mysqli_stmt_bind_param($stmt, $types, ...$params);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if ($result && mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                // Escapowanie poszczególnych pól tekstowych
                $id = htmlspecialchars($row['id'], ENT_QUOTES, 'UTF-8');
                $nazwa = htmlspecialchars($row['nazwa'], ENT_QUOTES, 'UTF-8');
                $opis = htmlspecialchars($row['opis'], ENT_QUOTES, 'UTF-8');
                $gatunek = htmlspecialchars($row['gatunek'], ENT_QUOTES, 'UTF-8');
                $waga = htmlspecialchars($row['waga'], ENT_QUOTES, 'UTF-8');
                $author = htmlspecialchars($row['author'], ENT_QUOTES, 'UTF-8');
                $data = htmlspecialchars($row['data_wyslania'], ENT_QUOTES, 'UTF-8');
                $obrazek = $row['obrazek']; // Dane binarne bez escapowania
        
                echo "<div class='entry'>";
                echo "<h3>Nazwa: $nazwa</h3>";
                echo "<p>Opis: $opis</p>";
                echo "<p>Gatunek: $gatunek</p>";
                echo "<p>Waga: $waga kg</p>";
                echo "<p>Autor: $author</p>";
                echo "<p>Wysłano: $data</p>";
        
                // Wyświetlanie obrazka
                if (!empty($obrazek)) {
                    $image_data = base64_encode($obrazek);
                    echo "<img src='data:image/png;base64,$image_data' alt='Zdjęcie'>";
                }
        
                // Przyciski akcji z tokenem CSRF
                echo '<div class="entry">';
                echo '<a href="edit_entry.php?id=' . $id . '" class="btn-edit">Edytuj</a>';
                echo '<form method="post" onsubmit="return confirmDelete(' . $id . ')">';
                echo '<input type="hidden" name="csrf_token" value="' . $_SESSION['csrf_token'] . '">';
                echo '<input type="hidden" name="entry_id" value="' . $id . '">';
                echo '<button type="submit" name="delete_entry" class="btn-delete">Usuń</button>';
                echo '</form>';
                echo '<a href="download_image.php?id=' . $id . '" class="btn-download">Pobierz zdjęcie</a>';
                echo '</div>';
        
                // Komentarze
                echo "<h4>Komentarze:</h4>";
$comments_query = "SELECT k.*, r.profile_image 
                  FROM komentarze_pod_wpisem k 
                  JOIN rejestracjatesy r ON k.author = r.username 
                  WHERE wpis_id = ? 
                  ORDER BY data_dodania DESC";
$stmt_comments = mysqli_prepare($connection, $comments_query);
mysqli_stmt_bind_param($stmt_comments, "i", $row['id']);
mysqli_stmt_execute($stmt_comments);
$comments_result = mysqli_stmt_get_result($stmt_comments);

if ($comments_result && mysqli_num_rows($comments_result) > 0) {
    while ($comment = mysqli_fetch_assoc($comments_result)) {
        $comment_author = htmlspecialchars($comment['author'], ENT_QUOTES, 'UTF-8');
        $comment_text = htmlspecialchars($comment['komentarz'], ENT_QUOTES, 'UTF-8');
        $comment_date = date('d.m.Y H:i', strtotime($comment['data_dodania']));
        $profile_image = htmlspecialchars($comment['profile_image'] ?? '', ENT_QUOTES, 'UTF-8');

        echo '<div class="comment">';
        
        // Zdjęcie profilowe
        if (!empty($profile_image)) {
            echo '<img src="' . $profile_image . '?t=' . time() . '" 
                      class="profile-image" 
                      alt="Profil ' . $comment_author . '"
                      onerror="this.onerror=null;this.parentNode.replaceChild(createDefaultAvatar(this),this)">';
        } else {
            echo '<div class="default-avatar">';
            echo strtoupper(substr($comment_author, 0, 2));
            echo '</div>';
        }

        echo '<div class="comment-body">';
        echo '<div class="comment-header">';
        echo '<span class="comment-author">' . $comment_author . '</span>';
        echo '<span class="comment-date">' . $comment_date . '</span>';
        echo '</div>';
        echo '<p class="comment-text">' . $comment_text . '</p>';
        echo '</div></div>';
    }
} else {
    echo "<p>Brak komentarzy.</p>";
}
        
                // Formularz wiadomości do admina
                echo "<form method='post' action='send_message_to_ADMIN_history_page_user.php'>";
                echo "<input type='hidden' name='csrf_token' value='" . $_SESSION['csrf_token'] . "'>";
                echo "<input type='hidden' name='entry_id' value='$id'>";
                echo "<textarea name='message_ADMIN' rows='4' required></textarea>";
                echo "<input type='submit' value='Wyślij wiadomość'>";
                echo "</form>";
                
                echo "</div>";
            }
        } else {
            echo "<h2>Brak wpisów do wyświetlenia.</h2>";
        }
        ?>
    </div>
</body>
</html>
