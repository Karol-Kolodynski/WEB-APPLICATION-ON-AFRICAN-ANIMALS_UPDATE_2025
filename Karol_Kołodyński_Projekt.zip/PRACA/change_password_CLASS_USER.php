<?php
session_start();
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

if (!isset($_SESSION['user']) || $_SESSION['user'] == "") {
    header("Location: login_page.php");
    exit();
}

$connection = mysqli_connect("localhost", "root", "", "afryka_blog");

if (!$connection) {
    die("Błąd połączenia z bazą danych: " . mysqli_connect_error());
}

$new_password = $_POST['new_password'];
$current_password = $_POST['current_password'];
$username = $_SESSION['user'];

$query = "SELECT passwordd FROM rejestracjatesy WHERE username = ?";
$stmt = mysqli_prepare($connection, $query);
mysqli_stmt_bind_param($stmt, "s", $username);
mysqli_stmt_execute($stmt);
mysqli_stmt_bind_result($stmt, $stored_hashed_password);
mysqli_stmt_fetch($stmt);
mysqli_stmt_close($stmt);

if (password_verify($current_password, $stored_hashed_password)) {
    $new_hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

    $update_query = "UPDATE rejestracjatesy SET passwordd = ? WHERE username = ?";
    $stmt = mysqli_prepare($connection, $update_query);
    mysqli_stmt_bind_param($stmt, "ss", $new_hashed_password, $username);

    if (mysqli_stmt_execute($stmt)) {
        $_SESSION['success'] = "Hasło zostało pomyślnie zmienione!";

        $queryAuthorEmail = "SELECT email FROM rejestracjatesy WHERE username = ?";
        $stmtAuthorEmail = mysqli_prepare($connection, $queryAuthorEmail);
        mysqli_stmt_bind_param($stmtAuthorEmail, "s", $username);
        mysqli_stmt_execute($stmtAuthorEmail);
        mysqli_stmt_bind_result($stmtAuthorEmail, $user_email);
        mysqli_stmt_fetch($stmtAuthorEmail);
        mysqli_stmt_close($stmtAuthorEmail);

        sendEmailNotification($username, $user_email, $connection);
    } else {
        $_SESSION['error'] = "Nie udało się zmienić hasła: " . mysqli_error($connection);
    }
} else {
    $_SESSION['error'] = "Podane aktualne hasło jest niepoprawne.";
}

mysqli_close($connection);
header("Location: change_data_user_page.php");
exit();

// Funkcja do wysyłania powiadomień
function sendEmailNotification($username, $user_email, $connection) {
    $mail = new PHPMailer(true);
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'afrykablog1@gmail.com';
    $mail->Password = 'jopq wujs maht xkxm';
    $mail->SMTPSecure = 'ssl';
    $mail->Port = 465;
    $mail->setFrom('afrykablog1@gmail.com');
    $mail->addAddress($user_email);
    $mail->isHTML(true);
    $mail->Subject = "$username: Zmiana hasła";
    $mail->Body = "<p>Twoje hasło zostało pomyślnie zmienione.</p>";
    $mail->CharSet = 'UTF-8';
    $mail->Encoding = 'base64';
    $mail->setLanguage('pl');
    $mail->send();
}
?>
