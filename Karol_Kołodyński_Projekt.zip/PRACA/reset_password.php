<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

$connection = new mysqli("localhost", "root", "", "afryka_blog");
if ($connection->connect_error) {
    die("Błąd połączenia: " . $connection->connect_error);
}

// Weryfikacja tokena z URL (Bezpieczny link resetu)
if (!isset($_GET['token'])) {
    $_SESSION['error'] = "Nieprawidłowy link resetujący";
    header("Location: forgot_password_page.php");
    exit();
}

// Oczyszczenie tokena przed użyciem w zapytaniu SQL
$urlToken = $connection->real_escape_string($_GET['token']);

// Sprawdzenie ważności tokena w bazie
// - Warunek expires > NOW() blokuje przedawnione linki
// - Prepared statement zapobiega SQL injection
$stmt = $connection->prepare("SELECT user_id, code, expires FROM password_resets WHERE url_token = ? AND expires > NOW()");
$stmt->bind_param("s", $urlToken);
$stmt->execute();
$result = $stmt->get_result();

// Obsługa błędów tokena
if ($result->num_rows === 0) {
    $_SESSION['error'] = "Nieprawidłowy lub przedawniony link";
    header("Location: forgot_password_page.php");
    exit();
}

$row = $result->fetch_assoc();

// Weryfikacja kodu (Dwuetapowa weryfikacja)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['code'], $_POST['csrf_token'])) {
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        die("Nieprawidłowa próba wysłania formularza");
    }

    if ($_POST['code'] == $row['code']) {
        $_SESSION['reset_user'] = $row['user_id'];
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        header("Location: verify_reset.php");
        exit();
    } else {
        $_SESSION['error'] = "Nieprawidłowy kod weryfikacyjny";
    }
}

// Generowanie nowego tokena CSRF dla formularza

$_SESSION['csrf_token'] = bin2hex(random_bytes(32));
?>
<!DOCTYPE html>
<html>
<head>
    <title>Weryfikacja kodu</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="CSS/responsive_create_account.css">
</head>
<body>
    <div class="container">
        <h2>Wprowadź kod z maila</h2>
        
        <?php if(isset($_SESSION['error'])): ?>
            <div class="error"><?= $_SESSION['error']; unset($_SESSION['error']) ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
            <div class="form-group">
                <label>Kod weryfikacyjny (6 cyfr):</label>
                <input type="number" name="code" min="100000" max="999999" required>
            </div>
            <div class="form-group">
                <input type="submit" value="Zweryfikuj">
            </div>
        </form>
    </div>
</body>
</html>