<?php
session_start();

// Weryfikacja autoryzacji
if (!isset($_SESSION['user'])) {
    header("HTTP/1.1 403 Forbidden");
    exit();
}

// Funkcja sanitizacji nazw plików - ochrona przed Path Traversal
function sanitizeFilename($filename) {
    // Usuń wszystkie znaki specjalne poza alfanumerycznymi i podkreśleniami
    $filename = preg_replace('/[^a-zA-Z0-9_-]/', '', $filename);
    
    // Usuń próby directory traversal
    $filename = str_replace(['..', '/', '\\'], '', $filename);
    
    // Ogranicz długość nazwy pliku
    return substr($filename, 0, 50);
}

// Połączenie z bazą danych
$connection = new mysqli("localhost", "root", "", "afryka_blog");
if ($connection->connect_error) {
    die("Błąd połączenia z bazą danych");
}

// Walidacja i sanityzacja ID wpisu
$entry_id = filter_input(INPUT_POST, 'entry_id', FILTER_VALIDATE_INT);
if (!$entry_id || $entry_id <= 0) {
    die("Nieprawidłowy identyfikator wpisu");
}

// Weryfikacja tokena CSRF
if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    die("Nieprawidłowy token CSRF");
}

// Pobierz dane z bazy
$stmt = $connection->prepare("SELECT obrazek, nazwa FROM wpisy WHERE id = ?");
$stmt->bind_param("i", $entry_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("Plik nie istnieje");
}

$row = $result->fetch_assoc();

// Walidacja typu MIME
$finfo = new finfo(FILEINFO_MIME_TYPE);
$mime_type = $finfo->buffer($row['obrazek']);
$allowed_types = [
    'image/jpeg' => 'jpg',
    'image/png' => 'png'
];

if (!array_key_exists($mime_type, $allowed_types)) {
    die("Nieobsługiwany typ pliku");
}

// Generuj bezpieczną nazwę pliku
$safe_name = sanitizeFilename($row['nazwa']) . '.' . $allowed_types[$mime_type];

// Nagłówki zabezpieczające
header("Content-Type: " . $mime_type);
header("Content-Disposition: attachment; filename=\"" . $safe_name . "\""); 
header("Content-Length: " . strlen($row['obrazek']));
header("X-Content-Type-Options: nosniff");

echo $row['obrazek'];
exit();
?>