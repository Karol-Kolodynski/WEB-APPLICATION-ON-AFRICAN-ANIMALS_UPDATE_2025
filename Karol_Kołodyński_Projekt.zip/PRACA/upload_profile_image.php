<?php
session_start();

// Konfiguracja środowiska
define('DEV_MODE', true); // Zmień na false w produkcji
define('ALLOWED_LOCAL_IPS', ['127.0.0.1', '::1']);
define('ALLOWED_DOMAINS', ['localhost', 'twoja-lokalna-domena.test']);

if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== ($_SESSION['csrf_token'] ?? '')) {
    die("Nieprawidłowy token CSRF");
}

if (!isset($_SESSION['user'])) {
    header("Location: login_page.php");
    exit();
}

$connection = new mysqli("localhost", "root", "", "afryka_blog");
if ($connection->connect_error) {
    die("Błąd połączenia: " . $connection->connect_error);
}

function isAllowedHost($host) {
    // Sprawdź czy host jest w białej liście
    if (in_array($host, ALLOWED_DOMAINS)) return true;
    
    // Sprawdź IP
    $ip = gethostbyname($host);
    return in_array($ip, ALLOWED_LOCAL_IPS);
}

function validateImageURL($url) {
    $parsed = parse_url($url);
    if (!$parsed || !isset($parsed['host'])) return false;

    // Zezwalaj na localhost w trybie developerskim
    if (DEV_MODE && isAllowedHost($parsed['host'])) {
        return preg_match('/\.(jpe?g|png|gif)$/i', $parsed['path']);
    }

    // Reszta logiki bezpieczeństwa dla środowiska produkcyjnego
    $path = $parsed['path'] ?? '';
    if (!preg_match('/\.(jpe?g|png|gif)$/i', $path)) return false;
    
    $ip = gethostbyname($parsed['host']);
    $privateRanges = [
        '10.0.0.0/8',
        '172.16.0.0/12',
        '192.168.0.0/16'
    ];
    
    foreach ($privateRanges as $range) {
        if (ip_in_range($ip, $range)) return false;
    }
    
    return true;
}

// Funkcja pomocnicza do sprawdzania zakresów IP
function ip_in_range($ip, $range) {
    list($subnet, $mask) = explode('/', $range);
    $ip_long = ip2long($ip);
    $subnet_long = ip2long($subnet);
    $mask_long = ~((1 << (32 - $mask)) - 1);
    return ($ip_long & $mask_long) === ($subnet_long & $mask_long);
}

// Zmodyfikowana walidacja URL
$image_url = filter_var($_POST['image_url'] ?? '', FILTER_VALIDATE_URL);
if (!$image_url || !validateImageURL($image_url)) {
    $_SESSION['error'] = "Nieprawidłowy URL obrazu";
    header("Location: change_data_user_page.php");
    exit();
}

// Konfiguracja cURL dla środowiska developerskiego
$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL => $image_url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => DEV_MODE, // false w produkcji
    CURLOPT_MAXREDIRS => DEV_MODE ? 2 : 0,
    CURLOPT_TIMEOUT => 15,
    CURLOPT_PROTOCOLS => CURLPROTO_HTTP | CURLPROTO_HTTPS,
    CURLOPT_SSL_VERIFYPEER => !DEV_MODE,
    CURLOPT_SSL_VERIFYHOST => DEV_MODE ? 0 : 2,
]);

$image_data = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($http_code !== 200 || !$image_data) {
    $_SESSION['error'] = "Nie można pobrać obrazu";
    header("Location: change_data_user_page.php");
    exit();
}

$image_data = @file_get_contents($image_url);
if (!$image_data || strlen($image_data) > 2 * 1024 * 1024) {
    $_SESSION['error'] = "Obraz jest zbyt duży (max 2MB) lub nie można go pobrać";
    header("Location: change_data_user_page.php");
    exit();
}

$finfo = new finfo(FILEINFO_MIME_TYPE);
$mime = $finfo->buffer($image_data);
$allowed_types = ['image/jpeg', 'image/png', 'image/gif'];

if (!in_array($mime, $allowed_types)) {
    $_SESSION['error'] = "Nieobsługiwany format pliku";
    header("Location: change_data_user_page.php");
    exit();
}

try {
    $image = imagecreatefromstring($image_data);
    if (!$image) {
        throw new Exception("Nie udało się przetworzyć obrazu");
    }

    $width = imagesx($image);
    $height = imagesy($image);
    $new_width = min($width, 1024);
    $new_height = (int)($height * ($new_width / $width));

    $resized_image = imagecreatetruecolor($new_width, $new_height);
    imagecopyresampled($resized_image, $image, 0, 0, 0, 0, $new_width, $new_height, $width, $height);

    $filename = 'profile_' . md5($_SESSION['user']) . '.jpg';
    $filepath = 'profile_images/' . $filename;
    
    if (!is_dir('profile_images')) {
        mkdir('profile_images', 0755, true);
    }

    imagejpeg($resized_image, $filepath, 85);
    imagedestroy($image);
    imagedestroy($resized_image);

    $stmt = $connection->prepare("UPDATE rejestracjatesy SET profile_image = ? WHERE username = ?");
    $stmt->bind_param("ss", $filepath, $_SESSION['user']);
    
    if ($stmt->execute()) {
        // Aktualizuj czas modyfikacji w sesji
        $_SESSION['profile_updated'] = time();
        $_SESSION['success'] = "Zdjęcie profilowe zostało zaktualizowane!";
    } else {
        throw new Exception("Błąd aktualizacji bazy danych");
    }
} catch (Exception $e) {
    $_SESSION['error'] = "Błąd: " . $e->getMessage();
}

$connection->close();
header("Location: change_data_user_page.php?" . http_build_query([
    'v' => time(), // Dodaj parametr wersji
    'rand' => bin2hex(random_bytes(4)) // Dodatkowy parametr losowy
]));
exit();
?>