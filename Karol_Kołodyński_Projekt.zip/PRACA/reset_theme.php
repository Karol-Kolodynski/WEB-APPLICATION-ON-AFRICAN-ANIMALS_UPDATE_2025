<?php
session_start();

// Wzmocnienie sesji
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure', 1);
ini_set('session.use_only_cookies', 1);

// Sprawdź, czy użytkownik jest zalogowany
if (!isset($_SESSION['user'])) {
    die("Błąd: Brak użytkownika w sesji!");
}

// Sprawdź CSRF Token
if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    die("Błąd bezpieczeństwa: Nieprawidłowy token CSRF");
}

// Połącz się z bazą danych (bezpieczeństwo połączenia)
$connection = new mysqli("localhost", "root", "", "afryka_blog");

if ($connection->connect_error) {
    error_log("Błąd bazy: " . $connection->connect_error);
    $_SESSION['error'] = "Błąd systemu";
    header("Location: change_data_user_page.php");
    exit();
}

// Pobierz nazwę użytkownika z sesji (zapobiega SSTI)
// Pobierz nazwę użytkownika
$username = $_SESSION['user'];
if (!preg_match('/^[a-zA-Z0-9_-]+$/', $username)) {
    $connection->close();
    $_SESSION['error'] = "Nieprawidłowy użytkownik";
    header("Location: change_data_user_page.php");
    exit();
}


// Pobierz ścieżkę do pliku CSS
$sql = "SELECT custom_css_path FROM rejestracjatesy WHERE username = ?";
$stmt = $connection->prepare($sql);

if (!$stmt) {
    die("Błąd przygotowania zapytania: " . $connection->error);
}

$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$css_path = $row['custom_css_path'] ?? '';

$stmt->close();

// Usuń plik fizycznie, jeśli istnieje
if (!empty($css_path) && file_exists($css_path)) {
    if (!unlink($css_path)) {
        error_log("Nie udało się usunąć pliku: " . htmlspecialchars($css_path));
        die("Nie udało się usunąć pliku.");
    }
}

// Wyczyść `custom_css_path` w bazie (zamiast usuwać użytkownika)
$sql = "UPDATE rejestracjatesy SET custom_css_path = NULL WHERE username = ?";
$stmt = $connection->prepare($sql);

if (!$stmt) {
    die("Błąd przygotowania zapytania UPDATE: " . $connection->error);
}

$stmt->bind_param("s", $username);

if (!$stmt->execute()) {
    die("Błąd wykonania zapytania UPDATE: " . $stmt->error);
}

$stmt->close();
$connection->close();

// Reset cache CSS
$_SESSION['css_version'] = time();

// Przekierowanie po zakończeniu operacji
$_SESSION['success'] = "Motyw został zresetowany!";
header("Location: change_data_user_page.php");
exit();
?>
