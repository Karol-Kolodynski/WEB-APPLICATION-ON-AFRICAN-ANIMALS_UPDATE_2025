<?php
session_start();

// Inicjalizacja tokena CSRF (Zabezpieczenie przed atakami CSRF)
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <!-- Meta tagi dla responsywności -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Podłączenie stylów CSS -->
    <link rel="stylesheet" type="text/css" href="CSS/responsive_create_account.css">
    <title>Reset hasła</title>
</head>
<body>
    <div class="container">
        <h2>Resetowanie hasła</h2>
        
        <!-- Wyświetlanie komunikatów błędów -->
        <?php if (isset($_SESSION['error'])): ?>
            <div class="error"><?= $_SESSION['error']; unset($_SESSION['error']); ?></div>
        <?php endif; ?>
        
        <!-- Wyświetlanie komunikatów sukcesu -->
        <?php if (isset($_SESSION['success'])): ?>
            <div class="success"><?= $_SESSION['success']; unset($_SESSION['success']); ?></div>
        <?php endif; ?>

        <!-- Formularz resetu hasła -->
        <form method="POST" action="forgot_password.php">
            <!-- Pole ukryte z tokenem CSRF -->
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
            
            <div class="form-group">
                <label for="email">Adres e-mail:</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <input type="submit" value="Wyślij kod resetu">
            </div>
        </form>
    </div>
</body>
</html>