<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

$connection = new mysqli("localhost", "root", "", "afryka_blog");
if ($connection->connect_error) {
    die("Błąd połączenia: " . $connection->connect_error);
}

// Weryfikacja sesji resetu
if (!isset($_SESSION['reset_user'])) {
    header("Location: forgot_password_page.php");
    exit();
}

// Obsługa zmiany hasła
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['password'], $_POST['confirm_password'], $_POST['csrf_token'])) {
    
    // Weryfikacja CSRF - ochrona przed cross-site request forgery
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        die("Nieprawidłowa próba wysłania formularza");
    }

    $password = $_POST['password'];
    $confirm = $_POST['confirm_password'];
    $userId = $_SESSION['reset_user'];
    
    // Walidacja zgodności haseł
    if ($password !== $confirm) {
        $_SESSION['error'] = "Hasła nie są identyczne";
        header("Location: reset_password.php");
        exit();
    }
    
    // Walidacja siły hasła
    // 8 znaków, 1 wielka litera, 1 cyfra, 1 znak specjalny
    if (!preg_match('/^(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$/', $password)) {
        $_SESSION['error'] = "Hasło musi zawierać min. 8 znaków, 1 wielką literę, 1 cyfrę i 1 znak specjalny";
        header("Location: reset_password.php");
        exit();
    }
    
    // Bezpieczne hashowanie hasła
    // Aktualizacja hasła w bazie
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $connection->prepare("UPDATE rejestracjatesy SET passwordd = ? WHERE id = ?");
    $stmt->bind_param("si", $hashedPassword, $userId);
    
    if ($stmt->execute()) {
        // Czyszczenie tokenów resetu - zapobiega ponownemu użyciu
        $stmt = $connection->prepare("DELETE FROM password_resets WHERE user_id = ?");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        
        // Bezpieczne zniszczenie sesji
        // Regeneracja ID sesji przeciw fixation attack
        session_regenerate_id(true);
        session_destroy();
        
        $_SESSION['success'] = "Hasło zostało zmienione!";
        header("Location: login_page.php");
        exit();
    } else {
        $_SESSION['error'] = "Błąd aktualizacji hasła";
    }
}
// Nowy token CSRF dla każdego ładowania strony

$_SESSION['csrf_token'] = bin2hex(random_bytes(32));
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="CSS/responsive_create_account.css">
    <title>Reset hasła</title>
</head>
<body>
    <div class="container">
        <h2>Ustaw nowe hasło</h2>
        
        <?php if(isset($_SESSION['error'])): ?>
            <div class="error"><?= $_SESSION['error']; unset($_SESSION['error']) ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
            <div class="form-group">
                <label>Nowe hasło:</label>
                <input type="password" name="password" required>
            </div>
            <div class="form-group">
                <label>Potwierdź hasło:</label>
                <input type="password" name="confirm_password" required>
            </div>
            <button type="submit">Zapisz hasło</button>
        </form>
    </div>
</body>
</html>