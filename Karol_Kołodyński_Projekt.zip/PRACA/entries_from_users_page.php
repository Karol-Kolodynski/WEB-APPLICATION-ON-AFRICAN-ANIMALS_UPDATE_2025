<?php
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure', 1);
ini_set('session.cookie_samesite', 'Lax');
session_start();

ini_set('disable_functions', 'exec,shell_exec,system,passthru');

header("X-XSS-Protection: 1; mode=block");
header("X-Content-Type-Options: nosniff");
header("X-Frame-Options: DENY");
header("Referrer-Policy: strict-origin-when-cross-origin");
header("Content-Security-Policy: default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'");
header('Content-Type: text/html; charset=UTF-8');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

if (!isset($_SESSION['user'])) {
    header("Location: login_page.php");
    exit();
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$connection = mysqli_connect("localhost", "root", "", "afryka_blog");
if (!$connection) {
    die("Błąd połączenia: " . mysqli_connect_error());
}

$username = htmlspecialchars($_SESSION['user'], ENT_QUOTES, 'UTF-8');
$query = "SELECT custom_greeting, custom_css_path, profile_image FROM rejestracjatesy WHERE username = ?";
$stmt = mysqli_prepare($connection, $query);
mysqli_stmt_bind_param($stmt, "s", $username);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$row = mysqli_fetch_assoc($result);

$custom_greeting = htmlspecialchars($row['custom_greeting'] ?? 'Witaj');
$custom_css = htmlspecialchars($row['custom_css_path'] ?? '');
$profile_image = htmlspecialchars($row['profile_image'] ?? '');

$allowed_genres = ['all', 'Ssak', 'Ptak', 'Gad', 'Płaz', 'Ryba', 'Stawonoga', 'Inny'];
$selectedGenre = in_array($_GET['genre'] ?? '', $allowed_genres) ? $_GET['genre'] : 'all';

$allowed_orders = ['asc' => 'Od najstarszych', 'desc' => 'Od najnowszych'];
$selectedOrder = ($_GET['order'] ?? 'desc') === 'asc' ? 'asc' : 'desc';

function sanitizeFilename($filename) {
    return substr(str_replace(['..', '/', '\\', '%'], '', preg_replace('/[^a-zA-Z0-9-_\.]/', '', $filename)), 0, 50);
}

function sendEmailNotification($username, $authorEmail, $nazwa, $opis, $gatunek, $waga, $obrazek_zawartosc, $comment_text) {
    $mail = new PHPMailer(true);
    
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'afrykablog1@gmail.com';
        $mail->Password = 'jopq wujs maht xkxm';
        $mail->SMTPSecure = 'ssl';
        $mail->Port = 465;
        $mail->setFrom('afrykablog1@gmail.com', 'Afryka Blog');
        $mail->addAddress(filter_var($authorEmail, FILTER_SANITIZE_EMAIL));

        if (!filter_var($authorEmail, FILTER_VALIDATE_EMAIL)) {
            throw new Exception("Nieprawidłowy adres email");
        }

        $mail->Subject = htmlspecialchars("$username: skomentował Twój wpis", ENT_QUOTES, 'UTF-8');
        $mail->Body = sprintf(
            'Nowy komentarz od %s

            Treść komentarza: %s
            Wiadomość automatyczna - Afryka Blog',
            htmlspecialchars($username, ENT_QUOTES, 'UTF-8'),
            nl2br(htmlspecialchars($comment_text, ENT_QUOTES, 'UTF-8'))
        );

        if(!empty($obrazek_zawartosc)) {
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mime_type = $finfo->buffer($obrazek_zawartosc);
            $allowed_types = ['image/jpeg' => 'jpg', 'image/png' => 'png'];
            
            if (!array_key_exists($mime_type, $allowed_types)) {
                throw new Exception("Nieprawidłowy typ obrazka");
            }

            $mail->addStringEmbeddedImage(
                $obrazek_zawartosc,
                'obrazek_wpisu',
                sanitizeFilename('image.' . $allowed_types[$mime_type]),
                'base64',
                $mime_type
            );
        }

        $stmt = $GLOBALS['connection']->prepare("SELECT notification_turn FROM rejestracjatesy WHERE email = ?");
        $stmt->bind_param("s", $authorEmail);
        $stmt->execute();
        
        if ($stmt->get_result()->fetch_assoc()['notification_turn']) {
            $mail->send();
        }
    } catch (Exception $e) {
        error_log("Błąd mail: " . $e->getMessage());
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die("Nieprawidłowy token CSRF");
    }

    $comment_text = trim($_POST['comment'] ?? '');
    $comment_text = strip_tags($comment_text);
    $entry_id = filter_input(INPUT_POST, 'entry_id', FILTER_VALIDATE_INT);

    if (!$entry_id || strlen($comment_text) < 2 || strlen($comment_text) > 500) {
        $_SESSION['error'] = "Nieprawidłowe dane komentarza (2-500 znaków)";
        header("Location: entries_from_users_page.php");
        exit();
    }

    $stmt = mysqli_prepare($connection, 
        "INSERT INTO komentarze_pod_wpisem (wpis_id, komentarz, author, data_dodania) 
        VALUES (?, ?, ?, NOW())"
    );
    mysqli_stmt_bind_param($stmt, "iss", $entry_id, $comment_text, $_SESSION['user']);

    if (mysqli_stmt_execute($stmt)) {
        $stmt = mysqli_prepare($connection, 
            "SELECT w.*, r.email 
            FROM wpisy w 
            JOIN rejestracjatesy r ON w.author = r.username 
            WHERE w.id = ?"
        );
        mysqli_stmt_bind_param($stmt, "i", $entry_id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $data = mysqli_fetch_assoc($result);

        if ($data) {
            sendEmailNotification(
                $_SESSION['user'],
                $data['email'],
                $data['nazwa'],
                $data['opis'],
                $data['gatunek'],
                $data['waga'],
                $data['obrazek'],
                $comment_text
            );
        }
        $_SESSION['success'] = "Komentarz dodany!";
    } else {
        $_SESSION['error'] = "Błąd dodawania komentarza";
    }
    header("Location: entries_from_users_page.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="pl-PL">
<head>
    <title>Blog o zwierzętach afrykańskich - wpisy od użytkowników</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/responsive_user.css">
    <?php if (!empty($custom_css)): ?>
    <link rel="stylesheet" href="<?php echo $custom_css; ?>">
    <?php endif; ?>
    <style>
        .comment {
            display: flex;
            gap: 15px;
            margin: 15px 0;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 8px;
        }
        .profile-image-small {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
        }
        .default-avatar {
        width: 50px;
        height: 50px;
        border-radius: 50%;
        background: #007bff;
        color: white;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: bold;
        flex-shrink: 0;
    }
        .comment-content {
            flex: 1;
        }
        .comment-date {
            font-size: 0.8em;
            color: #666;
            margin-top: 5px;
        }
    </style>
    <script>
    function createDefaultAvatar(imgElement) {
        const div = document.createElement('div');
        div.className = 'default-avatar';
        const username = imgElement.alt.replace('Profil ', '');
        div.textContent = username.substring(0, 2).toUpperCase();
        return div;
    }
</script>
</head>
<body>
    <nav class="navbar">
        <ul class="menu">
            <li><a href="mainpage.html">Wyloguj się</a></li>
            <li><a href="mainpage_user.php">Powrót na główną stronę</a></li>
        </ul>
    </nav>

    <div class="container">
        <h2><?php echo $custom_greeting . ' ' . htmlspecialchars($_SESSION['user'], ENT_QUOTES, 'UTF-8'); ?></h2>

        <div class="form-group">
            <?php
            if (isset($_SESSION['success'])) {
                echo "<p><strong>" . htmlspecialchars($_SESSION['success'], ENT_QUOTES, 'UTF-8') . "</strong></p>";
                unset($_SESSION['success']);
            } elseif (isset($_SESSION['error'])) {
                echo "<p><strong>" . htmlspecialchars($_SESSION['error'], ENT_QUOTES, 'UTF-8') . "</strong></p>";
                unset($_SESSION['error']);
            }
            ?>
        </div>

        <form method="get">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>">
            
            <div class="form-group">
                <label for="genre">Wybierz gatunek:</label>
                <select name="genre" id="genre" class="form-control">
                    <?php foreach ($allowed_genres as $genre): ?>
                        <option value="<?= htmlspecialchars($genre, ENT_QUOTES, 'UTF-8') ?>" 
                            <?= $selectedGenre === $genre ? 'selected' : '' ?>>
                            <?= htmlspecialchars($genre, ENT_QUOTES, 'UTF-8') ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <label for="order">Sortuj według daty:</label>
                <select name="order" id="order" class="form-control">
                    <?php foreach ($allowed_orders as $key => $label): ?>
                        <option value="<?= htmlspecialchars($key, ENT_QUOTES, 'UTF-8') ?>" 
                            <?= $selectedOrder === $key ? 'selected' : '' ?>>
                            <?= htmlspecialchars($label, ENT_QUOTES, 'UTF-8') ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <input type="submit" value="Filtruj" class="btn btn-primary">
            </div>
        </form>

        <?php
        $query = "SELECT * FROM wpisy";
        $params = [];
        $types = "";
        
        if ($selectedGenre !== 'all') {
            $query .= " WHERE gatunek = ?";
            $params[] = $selectedGenre;
            $types .= "s";
        }
        
        $query .= " ORDER BY data_wyslania " . ($selectedOrder === 'asc' ? 'ASC' : 'DESC');
        
        $stmt = mysqli_prepare($connection, $query);
        if ($params) {
            mysqli_stmt_bind_param($stmt, $types, ...$params);
        }
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if ($result && mysqli_num_rows($result) > 0): 
            while ($row = mysqli_fetch_assoc($result)): ?>
                <div class='entry'>
                    <p><strong>Tytuł:</strong> <?= htmlspecialchars($row['nazwa'], ENT_QUOTES, 'UTF-8') ?></p>
                    <p><strong>Opis:</strong> <?= htmlspecialchars($row['opis'], ENT_QUOTES, 'UTF-8') ?></p>
                    <p><strong>Gatunek:</strong> <?= htmlspecialchars($row['gatunek'], ENT_QUOTES, 'UTF-8') ?></p>
                    <p><strong>Waga:</strong> <?= htmlspecialchars($row['waga'], ENT_QUOTES, 'UTF-8') ?> kg</p>
                    <p><strong>Autor:</strong> <?= htmlspecialchars($row['author'], ENT_QUOTES, 'UTF-8') ?></p>
                    <p><strong>Data dodania:</strong> <?= htmlspecialchars($row['data_wyslania'], ENT_QUOTES, 'UTF-8') ?></p>
                    
                    <form method="post" action="download_file_from_users.php" class="image-download-form">
                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>">
                        <input type="hidden" name="entry_id" value="<?= htmlspecialchars($row['id'], ENT_QUOTES, 'UTF-8') ?>">
                        <button type="submit" class="image-download-button">
                            <img src="data:image/jpeg;base64,<?= base64_encode($row['obrazek']) ?>" alt="Zdjęcie zwierzęcia" class="img-responsive">
                        </button>
                    </form>

                    <form method='post' action='entries_from_users_page.php' class='comment-form'>
                        <input type='hidden' name='csrf_token' value='<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>'>
                        <input type='hidden' name='entry_id' value='<?= htmlspecialchars($row['id'], ENT_QUOTES, 'UTF-8') ?>'>
                        <textarea 
                            name='comment' 
                            class='form-control' 
                            placeholder='Napisz komentarz' 
                            required
                            maxlength="500"
                            oninput="this.value = this.value.replace(/[<>]/g, '')"
                        ></textarea>
                        <input type='submit' value='Dodaj Komentarz' class='btn btn-success'>
                    </form>

                    <div class='comments'>
                        <?php
                        $comments_query = "SELECT k.*, r.profile_image 
                                        FROM komentarze_pod_wpisem k 
                                        JOIN rejestracjatesy r ON k.author = r.username 
                                        WHERE wpis_id = ? 
                                        ORDER BY data_dodania DESC";
                        $stmt_comments = mysqli_prepare($connection, $comments_query);
                        mysqli_stmt_bind_param($stmt_comments, "i", $row['id']);
                        mysqli_stmt_execute($stmt_comments);
                        $comments_result = mysqli_stmt_get_result($stmt_comments);

                        if ($comments_result && mysqli_num_rows($comments_result) > 0):
                            while ($comment = mysqli_fetch_assoc($comments_result)): ?>
                                <div class="comment">
                                    <?php if (!empty($comment['profile_image'])): ?>
                                        <img src="<?= htmlspecialchars($comment['profile_image'], ENT_QUOTES, 'UTF-8') ?>" 
                                            class="profile-image-small" 
                                            alt="Profil <?= htmlspecialchars($comment['author'], ENT_QUOTES, 'UTF-8') ?>">
                                    <?php else: ?>
                                        <div class="default-avatar"></div>
                                    <?php endif; ?>
                                    
                                    <div class="comment-content">
                                        <strong><?= htmlspecialchars($comment['author'], ENT_QUOTES, 'UTF-8') ?>:</strong>
                                        <?= htmlspecialchars($comment['komentarz'], ENT_QUOTES, 'UTF-8') ?>
                                        <div class="comment-date">
                                            <?= date('d.m.Y H:i', strtotime($comment['data_dodania'])) ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endwhile;
                        else: ?>
                            <p>Brak komentarzy.</p>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endwhile;
        else: ?>
            <h2>Brak wpisów do wyświetlenia.</h2>
        <?php endif; ?>
    </div>
</body>
</html>
<?php
mysqli_close($connection);
?>